from __future__ import annotations

import argparse
import base64
import hashlib
import hmac
import json
import os
import secrets
import sqlite3
import unicodedata
import uuid
from datetime import datetime, timedelta, timezone
from http import HTTPStatus
from http.cookies import SimpleCookie
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import unquote, urlparse

ROOT = Path(__file__).resolve().parent
DATA_DIR = ROOT / "data"
DB_PATH = DATA_DIR / "threat-emulation-control.sqlite3"
SESSION_COOKIE = "tec_session"
SESSION_HOURS = 8
PASSWORD_ITERATIONS = 310_000
MAX_ATTEMPTS = 5
ATTEMPT_WINDOW = timedelta(minutes=15)
MAX_JSON = 12 * 1024 * 1024
MAX_STATE = 2 * 1024 * 1024
MAX_EVIDENCE = 8 * 1024 * 1024
ALLOWED_IMAGES = {"image/png", "image/jpeg"}
BOOTSTRAP = {
    "id": "usr-bj-initial",
    "username": "BJ",
    "username_norm": "bj",
    "password_salt": "c4rgvcDi6YcLdTVN0XCYoA==",
    "password_hash": "RxMJ/WQ70ZMl/9uLJEPCEI2/GgTFmBJTThzkcI6ioJQ=",
    "password_iterations": 100_000,
}


def now() -> datetime:
    return datetime.now(timezone.utc)


def iso(value: datetime | None = None) -> str:
    return (value or now()).isoformat().replace("+00:00", "Z")


def normalize_username(value: object) -> tuple[str, str]:
    username = unicodedata.normalize("NFKC", str(value or "")).strip()
    if not username or len(username) > 80 or any(ord(char) < 32 or ord(char) == 127 for char in username):
        raise ValueError("Informe um nome de usuário válido com até 80 caracteres.")
    return username, username.casefold()


def validate_password(value: object) -> str:
    password = str(value or "")
    if not 8 <= len(password) <= 128 or not any(char.isupper() for char in password) or not any(not char.isalnum() for char in password):
        raise ValueError("A senha deve ter 8 a 128 caracteres, uma letra maiúscula e um caractere especial.")
    return password


def derive_password(password: str, salt_b64: str, iterations: int) -> str:
    digest = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), base64.b64decode(salt_b64), iterations, dklen=32)
    return base64.b64encode(digest).decode("ascii")


def connect() -> sqlite3.Connection:
    connection = sqlite3.connect(DB_PATH, timeout=10)
    connection.row_factory = sqlite3.Row
    connection.execute("PRAGMA foreign_keys = ON")
    connection.execute("PRAGMA busy_timeout = 10000")
    return connection


def initialize_database() -> None:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    with connect() as db:
        db.execute("PRAGMA journal_mode = WAL")
        db.executescript(
            """
            CREATE TABLE IF NOT EXISTS users (
              id TEXT PRIMARY KEY, username TEXT NOT NULL, username_norm TEXT NOT NULL UNIQUE,
              password_hash TEXT NOT NULL, password_salt TEXT NOT NULL, password_iterations INTEGER NOT NULL,
              created_at TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS sessions (
              token_hash TEXT PRIMARY KEY, user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
              created_at TEXT NOT NULL, expires_at TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS login_attempts (
              username_norm TEXT PRIMARY KEY, attempts INTEGER NOT NULL, window_started_at TEXT NOT NULL,
              blocked_until TEXT
            );
            CREATE TABLE IF NOT EXISTS exercise_state (
              id INTEGER PRIMARY KEY CHECK(id = 1), state_json TEXT NOT NULL,
              updated_by TEXT NOT NULL REFERENCES users(id), updated_at TEXT NOT NULL
            );
            CREATE TABLE IF NOT EXISTS evidence_files (
              id TEXT PRIMARY KEY, name TEXT NOT NULL, content_type TEXT NOT NULL, size INTEGER NOT NULL,
              sha256 TEXT NOT NULL, content BLOB NOT NULL, created_by TEXT NOT NULL REFERENCES users(id),
              created_at TEXT NOT NULL
            );
            """
        )
        total = db.execute("SELECT COUNT(*) FROM users").fetchone()[0]
        if total == 0:
            db.execute(
                "INSERT INTO users (id, username, username_norm, password_hash, password_salt, password_iterations, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)",
                (BOOTSTRAP["id"], BOOTSTRAP["username"], BOOTSTRAP["username_norm"], BOOTSTRAP["password_hash"], BOOTSTRAP["password_salt"], BOOTSTRAP["password_iterations"], iso()),
            )
    try:
        os.chmod(DB_PATH, 0o600)
    except OSError:
        pass


class ThreatEmulationHandler(SimpleHTTPRequestHandler):
    server_version = "ThreatEmulationControl/1.0"

    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=str(ROOT), **kwargs)

    def end_headers(self) -> None:
        self.send_header("X-Content-Type-Options", "nosniff")
        self.send_header("X-Frame-Options", "DENY")
        self.send_header("Referrer-Policy", "no-referrer")
        self.send_header("Permissions-Policy", "camera=(), microphone=(), geolocation=()")
        self.send_header("Content-Security-Policy", "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data: blob:; connect-src 'self'; font-src 'self'; object-src 'none'; base-uri 'self'; frame-ancestors 'none'")
        super().end_headers()

    def log_message(self, fmt: str, *args) -> None:
        print(f"[{iso()}] {self.client_address[0]} {fmt % args}")

    def json_response(self, payload: object, status: int = 200, cookie: str | None = None) -> None:
        data = json.dumps(payload, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(data)))
        self.send_header("Cache-Control", "no-store")
        if cookie:
            self.send_header("Set-Cookie", cookie)
        self.end_headers()
        self.wfile.write(data)

    def read_json(self, max_bytes: int = MAX_JSON) -> dict:
        try:
            length = int(self.headers.get("Content-Length", "0"))
        except ValueError as error:
            raise ValueError("Tamanho de requisição inválido.") from error
        if length <= 0 or length > max_bytes:
            raise ValueError("Requisição muito grande ou vazia.")
        if not self.headers.get("Content-Type", "").lower().startswith("application/json"):
            raise ValueError("Conteúdo inválido.")
        payload = json.loads(self.rfile.read(length))
        if not isinstance(payload, dict):
            raise ValueError("Conteúdo inválido.")
        return payload

    def same_origin(self) -> None:
        origin = self.headers.get("Origin")
        host = self.headers.get("Host")
        if not origin or not host or origin not in {f"http://{host}", f"https://{host}"}:
            raise PermissionError("Origem da requisição inválida.")

    def session_token(self) -> str | None:
        cookie = SimpleCookie(self.headers.get("Cookie", ""))
        morsel = cookie.get(SESSION_COOKIE)
        return morsel.value if morsel else None

    def require_user(self) -> sqlite3.Row:
        token = self.session_token()
        if not token:
            raise PermissionError("Sessão inválida ou expirada.")
        token_hash = hashlib.sha256(token.encode("utf-8")).hexdigest()
        with connect() as db:
            row = db.execute(
                "SELECT users.id, users.username, sessions.expires_at FROM sessions JOIN users ON users.id = sessions.user_id WHERE sessions.token_hash = ?",
                (token_hash,),
            ).fetchone()
            if not row or datetime.fromisoformat(row["expires_at"].replace("Z", "+00:00")) <= now():
                db.execute("DELETE FROM sessions WHERE token_hash = ?", (token_hash,))
                raise PermissionError("Sessão inválida ou expirada.")
            return row

    def handle_exception(self, error: Exception) -> None:
        if isinstance(error, PermissionError):
            status = HTTPStatus.UNAUTHORIZED if "Sessão" in str(error) else HTTPStatus.FORBIDDEN
        elif isinstance(error, json.JSONDecodeError):
            status = HTTPStatus.BAD_REQUEST
            error = ValueError("JSON inválido.")
        else:
            status = HTTPStatus.BAD_REQUEST
        self.json_response({"error": str(error) or "Falha inesperada."}, status)

    def do_GET(self) -> None:
        try:
            path = urlparse(self.path).path
            if path == "/api/auth/me":
                user = self.require_user()
                return self.json_response({"user": {"id": user["id"], "username": user["username"]}})
            if path == "/api/users":
                self.require_user()
                with connect() as db:
                    users = [dict(row) for row in db.execute("SELECT id, username, created_at AS createdAt FROM users ORDER BY username COLLATE NOCASE")]
                return self.json_response({"users": users})
            if path == "/api/state":
                self.require_user()
                with connect() as db:
                    row = db.execute("SELECT state_json, updated_at FROM exercise_state WHERE id = 1").fetchone()
                return self.json_response({"state": json.loads(row["state_json"]) if row else None, "updatedAt": row["updated_at"] if row else None})
            if path.startswith("/api/evidence/"):
                self.require_user()
                evidence_id = unquote(path.removeprefix("/api/evidence/"))
                with connect() as db:
                    row = db.execute("SELECT name, content_type, size, sha256, content FROM evidence_files WHERE id = ?", (evidence_id,)).fetchone()
                if not row:
                    return self.json_response({"error": "Evidência não encontrada."}, HTTPStatus.NOT_FOUND)
                content = row["content"]
                safe_name = row["name"].replace('"', "_").replace("\r", "_").replace("\n", "_")
                self.send_response(HTTPStatus.OK)
                self.send_header("Content-Type", row["content_type"])
                self.send_header("Content-Length", str(len(content)))
                self.send_header("Content-Disposition", f'inline; filename="{safe_name}"')
                self.send_header("Cache-Control", "private, no-store")
                self.send_header("X-Evidence-SHA256", row["sha256"])
                self.end_headers()
                return self.wfile.write(content)
            return super().do_GET()
        except Exception as error:
            self.handle_exception(error)

    def do_POST(self) -> None:
        try:
            self.same_origin()
            path = urlparse(self.path).path
            if path == "/api/auth/login":
                return self.login(self.read_json(8192))
            if path == "/api/auth/logout":
                token = self.session_token()
                if token:
                    with connect() as db:
                        db.execute("DELETE FROM sessions WHERE token_hash = ?", (hashlib.sha256(token.encode()).hexdigest(),))
                return self.json_response({"ok": True}, cookie=f"{SESSION_COOKIE}=; HttpOnly; SameSite=Strict; Path=/; Max-Age=0")
            user = self.require_user()
            if path == "/api/users":
                return self.create_user(self.read_json(8192))
            if path == "/api/evidence":
                return self.create_evidence(self.read_json(MAX_JSON), user["id"])
            raise ValueError("Rota não encontrada.")
        except Exception as error:
            self.handle_exception(error)

    def do_PUT(self) -> None:
        try:
            self.same_origin()
            if urlparse(self.path).path != "/api/state":
                raise ValueError("Rota não encontrada.")
            user = self.require_user()
            body = self.read_json(MAX_STATE)
            state = body.get("state")
            if not isinstance(state, dict) or not isinstance(state.get("exercises"), list):
                raise ValueError("Estrutura de dados inválida.")
            serialized = json.dumps(state, ensure_ascii=False, separators=(",", ":"))
            if len(serialized.encode("utf-8")) > MAX_STATE:
                raise ValueError("Base de exercícios excede o limite permitido.")
            updated_at = iso()
            with connect() as db:
                db.execute(
                    "INSERT INTO exercise_state (id, state_json, updated_by, updated_at) VALUES (1, ?, ?, ?) ON CONFLICT(id) DO UPDATE SET state_json = excluded.state_json, updated_by = excluded.updated_by, updated_at = excluded.updated_at",
                    (serialized, user["id"], updated_at),
                )
            self.json_response({"ok": True, "updatedAt": updated_at})
        except Exception as error:
            self.handle_exception(error)

    def do_DELETE(self) -> None:
        try:
            self.same_origin()
            user = self.require_user()
            path = urlparse(self.path).path
            if not path.startswith("/api/users/"):
                raise ValueError("Rota não encontrada.")
            target = unquote(path.removeprefix("/api/users/"))
            if target == user["id"]:
                raise ValueError("Não é possível excluir o usuário da sessão atual.")
            with connect() as db:
                if db.execute("SELECT COUNT(*) FROM users").fetchone()[0] <= 1:
                    raise ValueError("Mantenha ao menos um usuário cadastrado.")
                cursor = db.execute("DELETE FROM users WHERE id = ?", (target,))
                if cursor.rowcount == 0:
                    raise ValueError("Usuário não encontrado.")
            self.json_response({"ok": True})
        except Exception as error:
            self.handle_exception(error)

    def login(self, body: dict) -> None:
        _, username_norm = normalize_username(body.get("username"))
        password = str(body.get("password") or "")
        current = now()
        with connect() as db:
            attempt = db.execute("SELECT attempts, window_started_at, blocked_until FROM login_attempts WHERE username_norm = ?", (username_norm,)).fetchone()
            if attempt and attempt["blocked_until"] and datetime.fromisoformat(attempt["blocked_until"].replace("Z", "+00:00")) > current:
                self.json_response({"error": "Muitas tentativas. Aguarde 15 minutos e tente novamente."}, HTTPStatus.TOO_MANY_REQUESTS)
                return
            row = db.execute("SELECT * FROM users WHERE username_norm = ?", (username_norm,)).fetchone()
            salt = row["password_salt"] if row else BOOTSTRAP["password_salt"]
            iterations = row["password_iterations"] if row else BOOTSTRAP["password_iterations"]
            candidate = derive_password(password, salt, iterations)
            if not row or not hmac.compare_digest(candidate, row["password_hash"]):
                window_started = datetime.fromisoformat(attempt["window_started_at"].replace("Z", "+00:00")) if attempt else current
                in_window = current - window_started < ATTEMPT_WINDOW
                count = (attempt["attempts"] + 1) if attempt and in_window else 1
                blocked_until = iso(current + ATTEMPT_WINDOW) if count >= MAX_ATTEMPTS else None
                db.execute("INSERT INTO login_attempts (username_norm, attempts, window_started_at, blocked_until) VALUES (?, ?, ?, ?) ON CONFLICT(username_norm) DO UPDATE SET attempts=excluded.attempts, window_started_at=excluded.window_started_at, blocked_until=excluded.blocked_until", (username_norm, count, iso(window_started if in_window else current), blocked_until))
                self.json_response({"error": "Usuário ou senha inválidos."}, HTTPStatus.UNAUTHORIZED)
                return
            db.execute("DELETE FROM login_attempts WHERE username_norm = ?", (username_norm,))
            if row["password_iterations"] < PASSWORD_ITERATIONS:
                new_salt = base64.b64encode(secrets.token_bytes(16)).decode("ascii")
                db.execute("UPDATE users SET password_hash = ?, password_salt = ?, password_iterations = ? WHERE id = ?", (derive_password(password, new_salt, PASSWORD_ITERATIONS), new_salt, PASSWORD_ITERATIONS, row["id"]))
            db.execute("DELETE FROM sessions WHERE expires_at <= ?", (iso(current),))
            token = secrets.token_urlsafe(32)
            db.execute("INSERT INTO sessions (token_hash, user_id, created_at, expires_at) VALUES (?, ?, ?, ?)", (hashlib.sha256(token.encode()).hexdigest(), row["id"], iso(current), iso(current + timedelta(hours=SESSION_HOURS))))
        cookie = f"{SESSION_COOKIE}={token}; HttpOnly; SameSite=Strict; Path=/; Max-Age={SESSION_HOURS * 3600}"
        self.json_response({"user": {"id": row["id"], "username": row["username"]}}, cookie=cookie)

    def create_user(self, body: dict) -> None:
        username, username_norm = normalize_username(body.get("username"))
        password = validate_password(body.get("password"))
        salt = base64.b64encode(secrets.token_bytes(16)).decode("ascii")
        user_id = str(uuid.uuid4())
        created_at = iso()
        try:
            with connect() as db:
                db.execute("INSERT INTO users (id, username, username_norm, password_hash, password_salt, password_iterations, created_at) VALUES (?, ?, ?, ?, ?, ?, ?)", (user_id, username, username_norm, derive_password(password, salt, PASSWORD_ITERATIONS), salt, PASSWORD_ITERATIONS, created_at))
        except sqlite3.IntegrityError as error:
            raise ValueError("Este nome de usuário já existe.") from error
        self.json_response({"user": {"id": user_id, "username": username, "createdAt": created_at}}, HTTPStatus.CREATED)

    def create_evidence(self, body: dict, user_id: str) -> None:
        content_type = str(body.get("type") or "").lower()
        if content_type not in ALLOWED_IMAGES:
            raise ValueError("Envie evidências em PNG ou JPEG.")
        try:
            content = base64.b64decode(str(body.get("dataBase64") or ""), validate=True)
        except ValueError as error:
            raise ValueError("Conteúdo da evidência inválido.") from error
        if not content or len(content) > MAX_EVIDENCE:
            raise ValueError("Cada evidência deve ter até 8 MB.")
        if int(body.get("size") or 0) != len(content):
            raise ValueError("Tamanho da evidência inválido.")
        if content_type == "image/png" and not content.startswith(b"\x89PNG\r\n\x1a\n"):
            raise ValueError("Assinatura PNG inválida.")
        if content_type == "image/jpeg" and not content.startswith(b"\xff\xd8\xff"):
            raise ValueError("Assinatura JPEG inválida.")
        name = unicodedata.normalize("NFKC", str(body.get("name") or "evidencia"))
        name = "".join("_" if ord(char) < 32 or char in "/\\" else char for char in name).strip()[:180] or "evidencia"
        evidence_id = str(uuid.uuid4())
        digest = hashlib.sha256(content).hexdigest()
        with connect() as db:
            db.execute("INSERT INTO evidence_files (id, name, content_type, size, sha256, content, created_by, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)", (evidence_id, name, content_type, len(content), digest, content, user_id, iso()))
        self.json_response({"evidence": {"id": evidence_id, "name": name, "type": content_type, "size": len(content), "sha256": digest, "url": f"/api/evidence/{evidence_id}"}}, HTTPStatus.CREATED)


def main() -> None:
    parser = argparse.ArgumentParser(description="Threat Emulation Control local SQLite server")
    parser.add_argument("--host", default="127.0.0.1")
    parser.add_argument("--port", type=int, default=8000)
    args = parser.parse_args()
    initialize_database()
    server = ThreadingHTTPServer((args.host, args.port), ThreatEmulationHandler)
    print(f"Threat Emulation Control: http://{args.host}:{args.port}")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()


if __name__ == "__main__":
    main()
