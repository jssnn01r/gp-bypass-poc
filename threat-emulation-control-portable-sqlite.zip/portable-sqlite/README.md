# Threat Emulation Control — edição portátil

Aplicação local com backend Python padrão e banco SQLite. Não exige pacotes externos.

## Iniciar

Abra o PowerShell nesta pasta e execute:

```powershell
python server.py --host 127.0.0.1 --port 8000
```

Acesse `http://127.0.0.1:8000`.

Como alternativa no Windows, execute `./start-local.ps1`. O launcher procura automaticamente uma instalação válida do Python 3.

Credencial inicial: usuário `BJ` e a senha definida na entrega original do projeto.

## Armazenamento

- Exercícios, usuários, sessões e evidências ficam em `data/threat-emulation-control.sqlite3`.
- Senhas usam PBKDF2-HMAC-SHA256 com salt individual e 310.000 iterações.
- Sessões usam token aleatório armazenado somente como hash no SQLite e cookie `HttpOnly`/`SameSite=Strict`.
- Evidências PNG/JPEG são obrigatórias, armazenadas como BLOB e verificadas por SHA-256.
- Use **Exportar dados** e backup do diretório `data` periodicamente.

## Segurança

Esta edição possui backend local e controles de sessão, origem, tamanho, MIME, assinatura de arquivo e headers defensivos.

- Adequada para uso individual/offline em máquina confiável.
- Não expor diretamente à Internet.
- `python -m http.server` não é mais compatível porque não executa o backend SQLite.
- Para acesso por outros computadores ou Internet, use proxy HTTPS, firewall e backup do banco, ou a versão principal hospedada.

Por padrão o servidor escuta somente em `127.0.0.1`.
