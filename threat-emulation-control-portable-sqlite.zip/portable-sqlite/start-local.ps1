$ErrorActionPreference = "Stop"

$candidates = @(
  @{ Command = "python"; Prefix = @() },
  @{ Command = "py"; Prefix = @("-3") },
  @{ Command = "python3"; Prefix = @() }
)

$userProfilePath = [Environment]::GetFolderPath("UserProfile")
$codexRuntime = Join-Path $userProfilePath ".cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe"
if (Test-Path -LiteralPath $codexRuntime) {
  $candidates += @{ Command = $codexRuntime; Prefix = @() }
}

$selected = $null
foreach ($candidate in $candidates) {
  try {
    $command = Get-Command $candidate.Command -ErrorAction Stop
    & $command.Source @($candidate.Prefix) --version *> $null
    if ($LASTEXITCODE -eq 0) {
      $selected = @{ Path = $command.Source; Prefix = $candidate.Prefix }
      break
    }
  } catch {}
}

if (-not $selected) {
  throw "Python 3 não foi localizado. Instale o Python e execute: python server.py --host 127.0.0.1 --port 8000"
}

Set-Location -LiteralPath $PSScriptRoot
Write-Host "Threat Emulation Control: http://127.0.0.1:8000" -ForegroundColor Cyan
& $selected.Path @($selected.Prefix) .\server.py --host 127.0.0.1 --port 8000
