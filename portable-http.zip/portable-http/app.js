"use strict";

const STORAGE_KEY = "purple-team-control-v1";
const LOCAL_USERS_KEY = "purple-team-control-users-v1";
const LOCAL_SESSION_KEY = "purple-team-control-session-v1";
const LOCAL_ATTEMPTS_KEY = "purple-team-control-login-attempts-v1";
const PASSWORD_ITERATIONS = 100000;
const INITIAL_USER = {
  id: "user-bj",
  username: "BJ",
  usernameNorm: "bj",
  passwordSalt: "c4rgvcDi6YcLdTVN0XCYoA==",
  passwordHash: "RxMJ/WQ70ZMl/9uLJEPCEI2/GgTFmBJTThzkcI6ioJQ=",
  passwordIterations: PASSWORD_ITERATIONS,
  createdAt: "2026-10-16T00:00:00.000Z"
};
const routeState = { route: "dashboard", exerciseId: null };
let mitre = { tactics: [] };
let state;
let authUser = null;

const $ = (selector, root = document) => root.querySelector(selector);
const $$ = (selector, root = document) => [...root.querySelectorAll(selector)];
const esc = (value = "") => String(value).replace(/[&<>'"]/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;","'":"&#39;",'"':"&quot;"}[c]));
const nl = value => esc(value || "").replace(/\n/g, "<br>");
const nowIso = () => new Date().toISOString();
const dateTime = value => value ? new Intl.DateTimeFormat("pt-BR", { dateStyle: "short", timeStyle: "medium" }).format(new Date(value)) : "—";
const todayBr = () => new Intl.DateTimeFormat("pt-BR").format(new Date());
const uid = prefix => `${prefix}-${Date.now().toString(36)}-${Math.random().toString(36).slice(2,7)}`;
function demoState() {
  return {
    exercises: [{
      id: "PT-2026-001",
      quarter: "2026/Q3",
      title: "Validação de controles de identidade e endpoint",
      objectives: "Avaliar a capacidade de prevenção, telemetria e detecção para comportamentos de descoberta, acesso a credenciais e execução controlada em endpoints corporativos.",
      target: "Estações Windows do laboratório Purple Team e tenant de identidade homologado.",
      restrictions: "Executar somente com contas de teste, dentro da janela aprovada e sem coleta de dados reais.",
      participants: [
        { company: "EMPRESA", team: "Threat Hunting", name: "Ana Martins", role: "Coordenação", email: "ana.martins@example.com" },
        { company: "EMPRESA", team: "Engenharia de Detecção", name: "Carlos Lima", role: "Detecção", email: "carlos.lima@example.com" }
      ],
      schedule: {
        kickoff: { start: "2026-07-06", end: "2026-07-06" },
        preparation: { start: "2026-07-07", end: "2026-07-17" },
        execution: { start: "2026-07-20", end: "2026-08-07" },
        report: { start: "2026-08-10", end: "2026-08-21" },
        delivery: { start: "2026-08-24", end: "2026-08-24" }
      },
      result: "Os cenários concluídos produziram telemetria de endpoint, porém parte da atividade de descoberta não gerou alerta acionável no SecOps.",
      cleanup: "Contas de teste desabilitadas, artefatos removidos e snapshots do laboratório restaurados.",
      conclusions: "A visibilidade de endpoint foi adequada; a correlação entre identidade e endpoint precisa de melhoria.",
      summary: "Cobertura validada para três técnicas. Duas melhorias de detecção foram priorizadas e uma vulnerabilidade de configuração foi registrada.",
      detectionResults: "A telemetria esteve disponível em todos os cenários concluídos, mas somente metade gerou alerta.",
      capacitySummary: "Capacidade moderada: boa coleta de eventos e lacunas na correlação e no enriquecimento de alertas.",
      scenarios: [
        { id: "PT-2026-001-001", title: "Descoberta de informações do sistema", ttpId: "T1082", ttpName: "System Information Discovery", sourceIp: "10.20.30.41", procedure: "hostname && systeminfo", status: "complete", startAt: "2026-07-21T13:05:00.000Z", endAt: "2026-07-21T13:08:00.000Z", evidence: [{name:"console-systeminfo.png",size:0}], detection: { alert: "Não", log: "Sim", notes: "Evento disponível no EDR, sem regra de correlação.", evidence: [{name:"timeline-edr.png",size:0}] } },
        { id: "PT-2026-001-002", title: "Execução de PowerShell", ttpId: "T1059.001", ttpName: "PowerShell", sourceIp: "10.20.30.41", procedure: "powershell.exe -NoProfile -File .\\fixture.ps1", status: "complete", startAt: "2026-07-22T14:10:00.000Z", endAt: "2026-07-22T14:14:00.000Z", evidence: [], detection: { alert: "Sim", log: "Sim", notes: "Alerta criado e enriquecido com usuário e host.", evidence: [] } },
        { id: "PT-2026-001-003", title: "Credenciais em arquivos", ttpId: "T1552.001", ttpName: "Credentials In Files", sourceIp: "10.20.30.42", procedure: "Busca controlada por padrão canário em diretório de teste", status: "running", startAt: "2026-07-23T15:20:00.000Z", endAt: "", evidence: [], detection: { alert: "", log: "", notes: "", evidence: [] } },
        { id: "PT-2026-001-004", title: "Descoberta de contas de domínio", ttpId: "T1087.002", ttpName: "Domain Account", sourceIp: "10.20.30.42", procedure: "Consulta LDAP limitada a contas de laboratório", status: "pending", startAt: "", endAt: "", evidence: [], detection: { alert: "", log: "", notes: "", evidence: [] } },
        { id: "PT-2026-001-005", title: "Movimento lateral via serviço remoto", ttpId: "T1021.001", ttpName: "Remote Desktop Protocol", sourceIp: "10.20.30.43", procedure: "Sessão RDP entre hosts do laboratório", status: "skipped", startAt: "", endAt: "", skipReason: "Janela indisponível no servidor de destino.", evidence: [], detection: { alert: "", log: "", notes: "", evidence: [] } }
      ],
      actions: [
        { id: uid("act"), scenarioIds: ["PT-2026-001-001"], edr: "Criar detecção para enumeração encadeada de host.", other: "Correlacionar com consultas de identidade no SIEM.", preventive: "Restringir execução de utilitários de inventário fora do catálogo.", priority: "Alta", implemented: "Não" },
        { id: uid("act"), scenarioIds: ["PT-2026-001-002"], edr: "Enriquecer o alerta com assinatura e origem do script.", other: "", preventive: "Aplicar política de execução assinada.", priority: "Média", implemented: "Sim" }
      ],
      vulnerabilities: [
        { id: "PT-2026-001-V001", title: "Política de execução permissiva", description: "Host de laboratório permitiu execução de script não assinado sem restrição adicional.", severity: "Alta", cve: "—", cvss: "7.1", observation: "Revisar a política aplicada ao grupo de estações.", evidence: [{name:"policy-evidence.png",size:0}] }
      ],
      history: [{ version: "0.1", creator: "Ana Martins", date: "15/08/2026", description: "Primeira consolidação do exercício" }],
      createdAt: "2026-07-01T12:00:00.000Z",
      updatedAt: nowIso()
    }]
  };
}

function loadState() {
  try {
    const parsed = JSON.parse(localStorage.getItem(STORAGE_KEY));
    if (parsed && Array.isArray(parsed.exercises)) return parsed;
  } catch (_) {}
  const initial = demoState();
  localStorage.setItem(STORAGE_KEY, JSON.stringify(initial));
  return initial;
}

function saveState(message) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
  if (message) toast(message);
}

function toast(message) {
  const node = document.createElement("div");
  node.className = "toast";
  node.textContent = message;
  $("#toast-root").append(node);
  setTimeout(() => node.remove(), 3200);
}

function exerciseById(id = routeState.exerciseId) { return state.exercises.find(item => item.id === id); }
function statusClass(status) { return ({pending:"pending",running:"running",detection:"running",complete:"complete",skipped:"skipped"})[status] || "pending"; }
function statusLabel(status) { return ({pending:"Pendente",running:"Em execução",detection:"Aguardando detecção",complete:"Concluído",skipped:"Não executado"})[status] || status; }
function pct(part, total) { return total ? Math.round((part / total) * 100) : 0; }

function metrics(exercise) {
  const scenarios = exercise.scenarios || [];
  const completed = scenarios.filter(s => ["complete","skipped"].includes(s.status)).length;
  const executed = scenarios.filter(s => s.status === "complete").length;
  const ttpCount = new Set(scenarios.filter(s => s.status === "complete").map(s => s.ttpId)).size;
  const actionItems = exercise.actions || [];
  const actionDone = actionItems.filter(a => a.implemented === "Sim").length;
  const execution = pct(completed, scenarios.length);
  const action = pct(actionDone, actionItems.length);
  return { scenarios: scenarios.length, completed, executed, ttpCount, actionItems: actionItems.length, actionDone, execution, action, overall: Math.round((execution + action) / 2) };
}

function navigate(route, exerciseId = null) {
  if (!authUser) return showLogin();
  routeState.route = route;
  routeState.exerciseId = exerciseId;
  location.hash = exerciseId ? `${route}/${encodeURIComponent(exerciseId)}` : route;
  render();
  window.scrollTo({ top: 0, behavior: "smooth" });
}

function parseHash() {
  const [route, id] = location.hash.replace(/^#/, "").split("/");
  routeState.route = route || "dashboard";
  routeState.exerciseId = id ? decodeURIComponent(id) : null;
}

function setHeader(eyebrow, title) {
  $("#page-eyebrow").textContent = eyebrow;
  $("#page-title").textContent = title;
  const activeRoute = ["mitre", "users"].includes(routeState.route) ? routeState.route : "dashboard";
  $$(".nav-item[data-route]").forEach(btn => btn.classList.toggle("is-active", btn.dataset.route === activeRoute));
  $(".topbar-actions").hidden = routeState.route === "users";
}

function render() {
  if (!authUser) return showLogin();
  const page = $("#page");
  const exercise = exerciseById();
  if (routeState.route === "dashboard") return renderDashboard(page);
  if (routeState.route === "mitre") return renderMitre(page);
  if (routeState.route === "users") return renderUsers(page);
  if (!exercise) return navigate("dashboard");
  if (routeState.route === "operation") return renderOperation(page, exercise);
  if (routeState.route === "action") return renderAction(page, exercise);
  if (routeState.route === "vulnerabilities") return renderVulnerabilities(page, exercise);
  if (routeState.route === "edit") return renderEdit(page, exercise);
  navigate("dashboard");
}

async function api(url, options = {}) {
  const method = String(options.method || "GET").toUpperCase();
  const body = options.body ? JSON.parse(options.body) : {};

  if (url === "/api/auth/me" && method === "GET") {
    const user = currentLocalUser();
    if (!user) throw new Error("Autenticação necessária.");
    return { user: publicLocalUser(user) };
  }
  if (url === "/api/auth/login" && method === "POST") return localLogin(body);
  if (url === "/api/auth/logout" && method === "POST") {
    sessionStorage.removeItem(LOCAL_SESSION_KEY);
    return { ok: true };
  }

  const actor = currentLocalUser();
  if (!actor) throw new Error("Sua sessão terminou. Entre novamente.");
  if (url === "/api/users" && method === "GET") {
    return { users: readLocalUsers().map(publicLocalUser) };
  }
  if (url === "/api/users" && method === "POST") return createLocalUser(body);
  if (url.startsWith("/api/users/") && method === "DELETE") {
    return deleteLocalUser(decodeURIComponent(url.slice("/api/users/".length)), actor.id);
  }
  throw new Error("Operação local não reconhecida.");
}

function normalizeUsername(value) {
  return String(value || "").normalize("NFKC").trim().toLocaleLowerCase("pt-BR");
}

function readLocalUsers() {
  try {
    const users = JSON.parse(localStorage.getItem(LOCAL_USERS_KEY));
    if (Array.isArray(users) && users.length) return users;
  } catch (_) {}
  localStorage.setItem(LOCAL_USERS_KEY, JSON.stringify([INITIAL_USER]));
  return [{ ...INITIAL_USER }];
}

function writeLocalUsers(users) {
  localStorage.setItem(LOCAL_USERS_KEY, JSON.stringify(users));
}

function publicLocalUser(user) {
  return { id: user.id, username: user.username, createdAt: user.createdAt };
}

function currentLocalUser() {
  const id = sessionStorage.getItem(LOCAL_SESSION_KEY);
  return id ? readLocalUsers().find(user => user.id === id) || null : null;
}

function bytesToBase64(bytes) {
  let binary = "";
  bytes.forEach(byte => { binary += String.fromCharCode(byte); });
  return btoa(binary);
}

function base64ToBytes(value) {
  return Uint8Array.from(atob(value), char => char.charCodeAt(0));
}

async function deriveLocalPassword(password, saltBase64, iterations = PASSWORD_ITERATIONS) {
  if (!globalThis.crypto?.subtle) throw new Error("A autenticação local exige localhost ou HTTPS.");
  const key = await crypto.subtle.importKey("raw", new TextEncoder().encode(password), "PBKDF2", false, ["deriveBits"]);
  const bits = await crypto.subtle.deriveBits({ name: "PBKDF2", hash: "SHA-256", salt: base64ToBytes(saltBase64), iterations }, key, 256);
  return bytesToBase64(new Uint8Array(bits));
}

function safeEqual(left, right) {
  if (left.length !== right.length) return false;
  let result = 0;
  for (let index = 0; index < left.length; index += 1) result |= left.charCodeAt(index) ^ right.charCodeAt(index);
  return result === 0;
}

function readLoginAttempts() {
  try { return JSON.parse(localStorage.getItem(LOCAL_ATTEMPTS_KEY)) || {}; }
  catch (_) { return {}; }
}

function saveLoginAttempts(attempts) {
  localStorage.setItem(LOCAL_ATTEMPTS_KEY, JSON.stringify(attempts));
}

async function localLogin({ username, password }) {
  const usernameNorm = normalizeUsername(username);
  const attempts = readLoginAttempts();
  const entry = attempts[usernameNorm] || { count: 0, blockedUntil: 0 };
  if (entry.blockedUntil > Date.now()) {
    const minutes = Math.ceil((entry.blockedUntil - Date.now()) / 60000);
    throw new Error(`Muitas tentativas inválidas. Tente novamente em ${minutes} minuto${minutes === 1 ? "" : "s"}.`);
  }
  const user = readLocalUsers().find(item => item.usernameNorm === usernameNorm);
  const candidate = user ? await deriveLocalPassword(String(password || ""), user.passwordSalt, user.passwordIterations) : "";
  if (!user || !safeEqual(candidate, user.passwordHash)) {
    sessionStorage.removeItem(LOCAL_SESSION_KEY);
    entry.count += 1;
    entry.blockedUntil = entry.count >= 5 ? Date.now() + 15 * 60 * 1000 : 0;
    if (entry.blockedUntil) entry.count = 0;
    attempts[usernameNorm] = entry;
    saveLoginAttempts(attempts);
    throw new Error("Usuário ou senha inválidos.");
  }
  delete attempts[usernameNorm];
  saveLoginAttempts(attempts);
  sessionStorage.setItem(LOCAL_SESSION_KEY, user.id);
  return { user: publicLocalUser(user) };
}

async function createLocalUser({ username, password }) {
  const displayName = String(username || "").normalize("NFKC").trim();
  const usernameNorm = normalizeUsername(displayName);
  const secret = String(password || "");
  if (!displayName || displayName.length > 80) throw new Error("Informe um nome de usuário válido com até 80 caracteres.");
  if (secret.length < 8 || !/[A-Z]/.test(secret) || !/[^A-Za-z0-9]/.test(secret)) {
    throw new Error("A senha deve ter 8 caracteres, maiúscula e caractere especial.");
  }
  const users = readLocalUsers();
  if (users.some(user => user.usernameNorm === usernameNorm)) throw new Error("Este nome de usuário já está cadastrado.");
  const salt = new Uint8Array(16);
  crypto.getRandomValues(salt);
  const passwordSalt = bytesToBase64(salt);
  const user = {
    id: crypto.randomUUID ? crypto.randomUUID() : uid("user"),
    username: displayName,
    usernameNorm,
    passwordSalt,
    passwordHash: await deriveLocalPassword(secret, passwordSalt),
    passwordIterations: PASSWORD_ITERATIONS,
    createdAt: nowIso()
  };
  users.push(user);
  writeLocalUsers(users);
  return { user: publicLocalUser(user) };
}

function deleteLocalUser(id, actorId) {
  const users = readLocalUsers();
  if (id === actorId) throw new Error("O usuário da sessão atual não pode ser excluído.");
  if (users.length === 1) throw new Error("É necessário manter ao menos um usuário.");
  const remaining = users.filter(user => user.id !== id);
  if (remaining.length === users.length) throw new Error("Usuário não encontrado.");
  writeLocalUsers(remaining);
  return { ok: true };
}

function showLogin(message = "") {
  authUser = null;
  $("#app").classList.add("is-locked");
  $("#user-avatar").textContent = "PT";
  $("#user-name").textContent = "Acesso local";
  $("#user-context").textContent = "Autenticação necessária";
  $("#session-status").textContent = "Acesso local";
  $("#session-detail").textContent = "Sessão não iniciada";
  $(".topbar-actions").hidden = true;
  $("#page").innerHTML = `
    <section class="auth-stage">
      <div class="auth-intro">
        <p class="hero-kicker">PURPLE TEAM • CONTROLE CONTÍNUO</p>
        <h1>DEFESA E RESILIÊNCIA CIBERNÉTICA</h1>
        <p>Ambiente protegido para planejar, executar e consolidar exercícios de Purple Team.</p>
        <div class="auth-security"><span>◈</span><div><strong>Modo portátil</strong><small>Senha derivada por PBKDF2 e dados mantidos neste navegador.</small></div></div>
      </div>
      <div class="auth-card">
        <div class="auth-mark"><img src="./assets/logo-mark.png" alt=""><span>ACESSO À PLATAFORMA</span></div>
        <h2>Autenticação</h2>
        <p>Informe suas credenciais para continuar.</p>
        ${message ? `<div class="auth-alert">${esc(message)}</div>` : ""}
        <form data-form="login" autocomplete="on">
          <div class="field"><label>Usuário</label><input name="username" autocomplete="username" maxlength="80" required autofocus></div>
          <div class="field"><label>Senha</label><input name="password" type="password" autocomplete="current-password" maxlength="128" required></div>
          <button class="button button-red auth-submit" type="submit">Entrar com segurança</button>
        </form>
        <small class="auth-note">Controle local • não substitui autenticação de servidor</small>
      </div>
    </section>`;
}

function activateSession(user) {
  authUser = user;
  state = loadState();
  $("#app").classList.remove("is-locked");
  const initials = user.username.split(/\s+/).filter(Boolean).slice(0, 2).map(part => part[0]).join("").toUpperCase() || "U";
  $("#user-avatar").textContent = initials;
  $("#user-name").textContent = user.username;
  $("#user-context").textContent = "Usuário autenticado";
  $("#session-status").textContent = "Sessão ativa";
  $("#session-detail").textContent = "Encerrar no ícone ao lado";
  parseHash();
  if (routeState.route === "users") location.hash = "users";
  render();
}

function renderUsers(page) {
  setHeader("CONTROLE DE ACESSO", "Gestão de usuários");
  page.innerHTML = `
    <section class="user-admin-grid">
      <article class="panel">
        <div class="panel-head"><div><h2>Novo usuário</h2><p>Nome livre. Todos os usuários possuem o mesmo nível de acesso nesta versão.</p></div></div>
        <div class="panel-body">
          <form data-form="new-user" autocomplete="off">
            <div class="field"><label>Nome de usuário</label><input name="username" maxlength="80" required placeholder="Nome livre"></div>
            <div class="field"><label>Senha</label><input name="password" type="password" minlength="8" maxlength="128" required autocomplete="new-password"></div>
            <div class="field"><label>Confirmar senha</label><input name="passwordConfirm" type="password" minlength="8" maxlength="128" required autocomplete="new-password"></div>
            <div class="password-policy"><strong>Política obrigatória</strong><span>• mínimo de 8 caracteres</span><span>• ao menos uma letra maiúscula</span><span>• ao menos um caractere especial</span></div>
            <div class="form-actions"><button class="button button-red" type="submit">Criar usuário</button></div>
          </form>
        </div>
      </article>
      <article class="panel">
        <div class="panel-head"><div><h2>Usuários cadastrados</h2><p>O usuário da sessão atual não pode ser excluído.</p></div><span class="status status-complete" id="users-count">Carregando</span></div>
        <div class="panel-body" id="users-list"><div class="loading-state">Carregando usuários...</div></div>
      </article>
    </section>`;
  loadUsers();
}

async function loadUsers() {
  const list = $("#users-list");
  try {
    const payload = await api("/api/users", { method: "GET", headers: {} });
    $("#users-count").textContent = `${payload.users.length} cadastrado${payload.users.length === 1 ? "" : "s"}`;
    list.innerHTML = `<div class="user-list">${payload.users.map(user => `
      <div class="user-row">
        <div class="user-row-avatar">${esc(user.username.slice(0, 2).toUpperCase())}</div>
        <div><strong>${esc(user.username)}</strong><span>Criado em ${dateTime(user.createdAt)}</span></div>
        ${user.id === authUser.id
          ? '<span class="current-user">Sessão atual</span>'
          : `<button class="button button-ghost button-small" data-action="delete-user" data-user-id="${esc(user.id)}" data-user-name="${esc(user.username)}">Excluir</button>`}
      </div>`).join("")}</div>`;
  } catch (error) {
    list.innerHTML = `<div class="auth-alert">${esc(error.message)}</div>`;
  }
}

function renderDashboard(page) {
  setHeader("VISÃO GERENCIAL", "Exercícios de Purple Team");
  const all = state.exercises;
  const allScenarios = all.flatMap(e => e.scenarios || []);
  const coverage = new Set(allScenarios.filter(s => s.status === "complete").map(s => s.ttpId)).size;
  const openActions = all.flatMap(e => e.actions || []).filter(a => a.implemented !== "Sim").length;
  const active = all.filter(e => metrics(e).overall < 100).length;
  const avg = all.length ? Math.round(all.reduce((sum,e) => sum + metrics(e).overall,0) / all.length) : 0;
  const grouped = Object.groupBy ? Object.groupBy(all, e => e.quarter || "Sem quarter") : all.reduce((acc,e) => ((acc[e.quarter || "Sem quarter"] ||= []).push(e), acc), {});
  const quarters = Object.keys(grouped).sort().reverse();
  page.innerHTML = `
    <section class="hero">
      <div class="hero-card">
        <p class="hero-kicker">PURPLE TEAM • CONTROLE CONTÍNUO</p>
        <h2>DEFESA E RESILIÊNCIA CIBERNÉTICA</h2>
        <p>Consolide execução ofensiva, evidências, capacidade defensiva e plano de ação em uma visão única.</p>
      </div>
      <div class="hero-aside">
        <div class="metric-card"><span>Exercícios ativos</span><strong>${active}</strong><em>${all.length} cadastrados</em></div>
        <div class="metric-card"><span>TTPs cobertos</span><strong>${coverage}</strong><em>cobertura única</em></div>
        <div class="metric-card"><span>Ações abertas</span><strong>${openActions}</strong><em>engenharia de detecção</em></div>
        <div class="metric-card"><span>Progresso médio</span><strong>${avg}%</strong><em>execução + ação</em></div>
      </div>
    </section>
    <div class="section-head">
      <div><h2>Portfólio de exercícios</h2><p>Organizado por quarter e atualizado a partir dos registros operacionais.</p></div>
      <button class="button button-red" data-action="new-exercise">+ Criar exercício</button>
    </div>
    ${quarters.length ? quarters.map(quarter => `
      <section class="quarter-block">
        <div class="quarter-title">${esc(quarter)} <span>• ${grouped[quarter].length} exercício${grouped[quarter].length === 1 ? "" : "s"}</span></div>
        ${grouped[quarter].map(exerciseCard).join("")}
      </section>`).join("") : emptyBlock("Nenhum exercício cadastrado", "Crie o primeiro exercício para começar.", "new-exercise")}
  `;
}

function exerciseCard(exercise) {
  const m = metrics(exercise);
  return `<article class="exercise-card" data-exercise="${esc(exercise.id)}">
    <div class="exercise-summary">
      <div class="exercise-main">
        <button class="expand-button" data-action="toggle-exercise" data-id="${esc(exercise.id)}" aria-label="Expandir exercício">+</button>
        <div class="exercise-copy"><span class="exercise-id">${esc(exercise.id)}</span><h3>${esc(exercise.title)}</h3><p>${esc(exercise.target || "Ambiente alvo ainda não informado")}</p></div>
      </div>
      <div class="progress-compact"><div class="progress-label"><span>Conclusão geral</span><strong>${m.overall}%</strong></div><div class="progress-track"><i style="width:${m.overall}%"></i></div></div>
      <div class="action-strip">
        <button class="action-link" data-nav="operation" data-id="${esc(exercise.id)}">Operação</button>
        <button class="action-link" data-nav="action" data-id="${esc(exercise.id)}">Plano de ação</button>
        <button class="action-link" data-nav="vulnerabilities" data-id="${esc(exercise.id)}">Vulnerabilidades</button>
        <button class="action-link" data-nav="edit" data-id="${esc(exercise.id)}">Editar</button>
        <button class="action-link report" data-action="report" data-id="${esc(exercise.id)}">Exibir relatório</button>
      </div>
    </div>
    <div class="exercise-details">
      <div class="detail-grid">
        <div class="detail-stat"><span>Andamento da execução</span><strong>${m.execution}%</strong></div>
        <div class="detail-stat"><span>TTPs cobertos</span><strong>${m.ttpCount}</strong></div>
        <div class="detail-stat"><span>Plano de ação</span><strong>${m.action}%</strong></div>
        <div class="detail-stat"><span>Conclusão geral</span><strong>${m.overall}%</strong></div>
      </div>
    </div>
  </article>`;
}

function subnav(exercise, active) {
  const items = [["operation","Operação"],["action","Plano de Ação"],["vulnerabilities","Vulnerabilidades"],["edit","Editar exercício"]];
  return `<div class="subnav"><button data-nav="dashboard">← Voltar</button>${items.map(([route,label]) => `<button class="${active===route?"is-active":""}" data-nav="${route}" data-id="${esc(exercise.id)}">${label}</button>`).join("")}<button data-action="report" data-id="${esc(exercise.id)}">Gerar relatório</button></div>`;
}

function emptyBlock(title, text, action) {
  return `<div class="empty"><strong>${esc(title)}</strong><p>${esc(text)}</p>${action ? `<button class="button button-red" data-action="${action}">Adicionar</button>` : ""}</div>`;
}

function renderOperation(page, exercise) {
  setHeader(exercise.id, "Operação do exercício");
  const scenarios = exercise.scenarios || [];
  const m = metrics(exercise);
  page.innerHTML = `${subnav(exercise,"operation")}
    <section class="panel">
      <div class="panel-head"><div><h2>Cenários de execução</h2><p>${m.completed} de ${m.scenarios} cenários encerrados • ${m.ttpCount} TTPs cobertos</p></div><button class="button button-red" data-action="new-scenario" data-id="${esc(exercise.id)}">+ Novo cenário</button></div>
      <div class="panel-body">
        ${scenarios.length ? `<div class="records">${scenarios.map(s => scenarioRecord(exercise,s)).join("")}</div>` : emptyBlock("Nenhum cenário registrado", "Adicione o primeiro cenário operacional.", "new-scenario")}
      </div>
    </section>`;
}

function scenarioRecord(exercise, scenario) {
  const detectionVisible = ["detection","complete"].includes(scenario.status);
  return `<article class="record" data-record="${esc(scenario.id)}">
    <button class="record-summary" data-action="toggle-record" data-record="${esc(scenario.id)}">
      <span class="record-id">${esc(scenario.id)}</span><span class="record-title">${esc(scenario.title)}</span><span class="status status-${statusClass(scenario.status)}">${statusLabel(scenario.status)}</span>
    </button>
    <div class="record-content">
      <div class="record-details">
        <div><span>TTP MITRE</span><strong>${esc(scenario.ttpId)} • ${esc(scenario.ttpName)}</strong></div>
        <div><span>IP de origem</span><strong>${esc(scenario.sourceIp || "—")}</strong></div>
        <div><span>Início da execução</span><strong>${dateTime(scenario.startAt)}</strong></div>
        <div><span>Final da execução</span><strong>${dateTime(scenario.endAt)}</strong></div>
        <div class="wide"><span>Procedimento</span><p>${nl(scenario.procedure)}</p></div>
        <div><span>Evidências</span><strong>${(scenario.evidence || []).map(e => esc(e.name)).join(", ") || "Nenhuma evidência"}</strong></div>
        ${scenario.skipReason ? `<div><span>Motivo da não execução</span><p>${nl(scenario.skipReason)}</p></div>` : ""}
      </div>
      <div class="record-actions">
        ${scenario.status === "pending" ? `<button class="button button-red button-small" data-action="scenario-start" data-exercise="${esc(exercise.id)}" data-scenario="${esc(scenario.id)}">Iniciar</button>` : ""}
        ${scenario.status === "running" ? `<button class="button button-dark button-small" data-action="scenario-complete" data-exercise="${esc(exercise.id)}" data-scenario="${esc(scenario.id)}">Concluir execução</button>` : ""}
        ${scenario.status === "pending" ? `<button class="button button-ghost button-small" data-action="scenario-skip" data-exercise="${esc(exercise.id)}" data-scenario="${esc(scenario.id)}">Marcar não executado</button>` : ""}
        ${scenario.status !== "complete" && scenario.status !== "skipped" ? `<label class="button button-ghost button-small file-button">Anexar evidência<input type="file" data-evidence="scenario" data-exercise="${esc(exercise.id)}" data-scenario="${esc(scenario.id)}" multiple></label>` : ""}
      </div>
      ${detectionVisible ? detectionForm(exercise, scenario) : ""}
    </div>
  </article>`;
}

function detectionForm(exercise, scenario) {
  const d = scenario.detection || {};
  return `<form class="detection-box" data-form="detection" data-exercise="${esc(exercise.id)}" data-scenario="${esc(scenario.id)}">
    <h4>Detecção</h4>
    <div class="form-grid cols-3">
      <div class="field"><label>Alerta gerado</label><select name="alert" required><option value="">Selecione</option><option ${d.alert==="Sim"?"selected":""}>Sim</option><option ${d.alert==="Não"?"selected":""}>Não</option></select></div>
      <div class="field"><label>Log disponível</label><select name="log" required><option value="">Selecione</option><option ${d.log==="Sim"?"selected":""}>Sim</option><option ${d.log==="Não"?"selected":""}>Não</option></select></div>
      <div class="field"><label>Evidência de detecção</label><input type="file" name="evidence" multiple></div>
      <div class="field span-2"><label>Observações</label><textarea name="notes" required>${esc(d.notes || "")}</textarea></div>
      <div class="field"><label>Arquivos registrados</label><div>${(d.evidence || []).map(e=>esc(e.name)).join("<br>") || "Nenhum"}</div></div>
    </div>
    <div class="form-actions"><button class="button button-dark" type="submit">Salvar detecção e concluir</button></div>
  </form>`;
}

function renderAction(page, exercise) {
  setHeader(exercise.id, "Plano de ação");
  const actions = exercise.actions || [];
  page.innerHTML = `${subnav(exercise,"action")}
    <section class="panel">
      <div class="panel-head"><div><h2>Contexto de detecção</h2><p>Consolidação qualitativa da capacidade defensiva.</p></div></div>
      <div class="panel-body">
        <form data-form="action-context" data-exercise="${esc(exercise.id)}">
          <div class="form-grid">
            <div class="field"><label>Resultados de Detecção</label><textarea name="detectionResults">${esc(exercise.detectionResults || "")}</textarea></div>
            <div class="field"><label>Resumo da Capacidade</label><textarea name="capacitySummary">${esc(exercise.capacitySummary || "")}</textarea></div>
          </div><div class="form-actions"><button class="button button-dark" type="submit">Salvar contexto</button></div>
        </form>
      </div>
    </section>
    <section class="panel">
      <div class="panel-head"><div><h2>Ações de engenharia de detecção</h2><p>${actions.filter(a=>a.implemented==="Sim").length} de ${actions.length} regras implementadas.</p></div><button class="button button-red" data-action="new-action" data-id="${esc(exercise.id)}">+ Nova ação</button></div>
      <div class="panel-body">
        ${actions.length ? `<div class="table-wrap"><table class="data-table"><thead><tr><th>Cenário / IDs relacionados</th><th>Melhoria no EDR</th><th>Outras camadas</th><th>Medidas preventivas</th><th>Prioridade</th><th>Implementada</th><th></th></tr></thead><tbody>${actions.map(a => `<tr><td>${(a.scenarioIds||[]).map(esc).join("<br>")}</td><td>${nl(a.edr)}</td><td>${nl(a.other)}</td><td>${nl(a.preventive)}</td><td><strong>${esc(a.priority)}</strong></td><td><span class="status status-${a.implemented==="Sim"?"complete":"pending"}">${esc(a.implemented)}</span></td><td><button class="button button-ghost button-small" data-action="toggle-action" data-exercise="${esc(exercise.id)}" data-item="${esc(a.id)}">${a.implemented==="Sim"?"Reabrir":"Concluir"}</button></td></tr>`).join("")}</tbody></table></div>` : emptyBlock("Nenhuma ação registrada", "Associe um ou mais cenários a uma ação de melhoria.", "new-action")}
      </div>
    </section>`;
}

function renderVulnerabilities(page, exercise) {
  setHeader(exercise.id, "Vulnerabilidades");
  const vulns = exercise.vulnerabilities || [];
  const counts = {Crítica:0,Alta:0,Média:0,Baixa:0};
  vulns.forEach(v => counts[v.severity] = (counts[v.severity] || 0) + 1);
  page.innerHTML = `${subnav(exercise,"vulnerabilities")}
    <div class="vuln-layout">
      <aside class="tower-card"><h3>Torre de criticidade</h3><div class="tower">
        ${towerLevel("Baixa",counts.Baixa,"low")}${towerLevel("Média",counts.Média,"medium")}${towerLevel("Alta",counts.Alta,"high")}${towerLevel("Crítica",counts.Crítica,"critical")}
      </div></aside>
      <section class="panel">
        <div class="panel-head"><div><h2>Vulnerabilidades identificadas</h2><p>${vulns.length} registro${vulns.length===1?"":"s"} no exercício.</p></div><button class="button button-red" data-action="new-vulnerability" data-id="${esc(exercise.id)}">+ Nova vulnerabilidade</button></div>
        <div class="panel-body">${vulns.length ? `<div class="records">${vulns.map(v=>vulnerabilityRecord(v)).join("")}</div>` : emptyBlock("Nenhuma vulnerabilidade registrada", "Adicione achados identificados durante o exercício.", "new-vulnerability")}</div>
      </section>
    </div>`;
}

function towerLevel(label,count,slug) { return `<div class="tower-level tower-${slug} ${count?"":"tower-zero"}" style="min-height:${34 + Math.min(count,5)*14}px"><span>${label}</span><strong>${count}</strong></div>`; }
function vulnerabilityRecord(v) {
  return `<article class="record" data-record="${esc(v.id)}"><button class="record-summary" data-action="toggle-record" data-record="${esc(v.id)}"><span class="record-id">${esc(v.id)}</span><span class="record-title">${esc(v.title)}</span><span class="status status-${v.severity==="Crítica"?"skipped":v.severity==="Alta"?"skipped":v.severity==="Média"?"running":"pending"}">${esc(v.severity)}</span></button><div class="record-content"><div class="record-details"><div class="wide"><span>Descrição</span><p>${nl(v.description)}</p></div><div><span>CVE</span><strong>${esc(v.cve||"—")}</strong></div><div><span>CVSS</span><strong>${esc(v.cvss||"—")}</strong></div><div class="wide"><span>Observação</span><p>${nl(v.observation||"—")}</p></div><div><span>Evidências</span><strong>${(v.evidence||[]).map(e=>esc(e.name)).join(", ")||"Nenhuma"}</strong></div></div></div></article>`;
}

function renderEdit(page, exercise) {
  setHeader(exercise.id, "Editar exercício");
  const participants = exercise.participants || [];
  const scheduleRows = [["kickoff","Kick-off"],["preparation","Preparação"],["execution","Execução"],["report","Relatório"],["delivery","Entrega"]];
  page.innerHTML = `${subnav(exercise,"edit")}
    <section class="panel"><div class="panel-head"><div><h2>Informações do exercício</h2><p>Identificação, escopo e orientações de execução.</p></div></div><div class="panel-body">
      <form data-form="exercise-edit" data-exercise="${esc(exercise.id)}">
        <div class="form-grid cols-3">
          <div class="field"><label>ID</label><input name="id" value="${esc(exercise.id)}" readonly></div>
          <div class="field"><label>Quarter</label><input name="quarter" value="${esc(exercise.quarter)}" required></div>
          <div class="field"><label>Título</label><input name="title" value="${esc(exercise.title)}" required></div>
          <div class="field"><label>Objetivos</label><textarea name="objectives">${esc(exercise.objectives||"")}</textarea></div>
          <div class="field"><label>Ambiente alvo</label><textarea name="target">${esc(exercise.target||"")}</textarea></div>
          <div class="field"><label>Restrições</label><textarea name="restrictions">${esc(exercise.restrictions||"")}</textarea></div>
          <div class="field"><label>Resultado do exercício</label><textarea name="result">${esc(exercise.result||"")}</textarea></div>
          <div class="field"><label>Clean Up</label><textarea name="cleanup">${esc(exercise.cleanup||"")}</textarea></div>
          <div class="field"><label>Conclusões</label><textarea name="conclusions">${esc(exercise.conclusions||"")}</textarea></div>
          <div class="field span-2"><label>Resumo dos principais resultados</label><textarea name="summary">${esc(exercise.summary||"")}</textarea></div>
        </div><div class="form-actions"><button class="button button-dark" type="submit">Salvar informações</button></div>
      </form></div></section>
    <section class="panel"><div class="panel-head"><div><h2>Participantes</h2><p>Empresa, equipe, nome, função e contato.</p></div><button class="button button-red" data-action="add-participant" data-id="${esc(exercise.id)}">+ Participante</button></div><div class="panel-body">
      ${participants.length ? `<form data-form="participants" data-exercise="${esc(exercise.id)}"><div class="table-wrap"><table class="data-table"><thead><tr><th>Empresa</th><th>Equipe</th><th>Nome</th><th>Função</th><th>E-mail</th><th></th></tr></thead><tbody>${participants.map((p,i)=>`<tr data-participant="${i}"><td><input name="company" value="${esc(p.company)}"></td><td><input name="team" value="${esc(p.team)}"></td><td><input name="name" value="${esc(p.name)}"></td><td><input name="role" value="${esc(p.role)}"></td><td><input name="email" type="email" value="${esc(p.email)}"></td><td><button type="button" class="button button-danger button-small" data-action="remove-participant" data-exercise="${esc(exercise.id)}" data-index="${i}">×</button></td></tr>`).join("")}</tbody></table></div><div class="form-actions"><button class="button button-dark" type="submit">Salvar participantes</button></div></form>` : emptyBlock("Nenhum participante", "Inclua as pessoas e equipes envolvidas.", "add-participant")}
    </div></section>
    <section class="panel"><div class="panel-head"><div><h2>Cronograma</h2><p>Datas de início e fim de cada fase.</p></div></div><div class="panel-body"><form data-form="schedule" data-exercise="${esc(exercise.id)}"><div class="table-wrap"><table class="data-table schedule-table"><thead><tr><th>Fase</th><th>Início</th><th>Fim</th></tr></thead><tbody>${scheduleRows.map(([key,label])=>`<tr><td><strong>${label}</strong></td><td><input type="date" name="${key}-start" value="${esc(exercise.schedule?.[key]?.start||"")}"></td><td><input type="date" name="${key}-end" value="${esc(exercise.schedule?.[key]?.end||"")}"></td></tr>`).join("")}</tbody></table></div><div class="form-actions"><button class="button button-dark" type="submit">Salvar cronograma</button></div></form></div></section>`;
}

function uniqueTechniques() {
  const seen = new Map();
  mitre.tactics.forEach(t => t.techniques.forEach(item => { if (!seen.has(item.id)) seen.set(item.id, item); }));
  return [...seen.values()].sort((a,b) => a.id.localeCompare(b.id,undefined,{numeric:true}));
}

function coverageFor(techniqueId) {
  const rows = [];
  state.exercises.forEach(exercise => (exercise.scenarios || []).forEach(scenario => {
    if (scenario.ttpId === techniqueId && scenario.status === "complete") rows.push({ exercise, scenario });
  }));
  return rows;
}

function renderMitre(page) {
  setHeader("COBERTURA TÉCNICA", "Mapa MITRE ATT&CK Enterprise");
  page.innerHTML = `<div class="mitre-toolbar"><div class="search"><input id="mitre-search" placeholder="Buscar técnica, ID ou tática"></div><div class="legend"><span><i style="background:#fff;border:1px solid #ddd"></i>Não testado</span><span><i style="background:#a3002a"></i>1 exercício</span><span><i style="background:#6f2dbd"></i>2+ exercícios</span></div></div>
    <div class="mitre-board" id="mitre-board">${mitreColumns()}</div>
    <p style="font-size:10px;color:var(--muted);margin-top:8px">Fonte: MITRE ATT&CK Enterprise. Técnicas podem aparecer em mais de uma tática. Clique para ver a cobertura por exercício.</p>`;
}

function mitreColumns(query = "") {
  const q = query.trim().toLowerCase();
  return mitre.tactics.map(tactic => {
    const items = tactic.techniques.filter(item => !q || `${item.id} ${item.name} ${tactic.name}`.toLowerCase().includes(q));
    if (q && !items.length) return "";
    return `<section class="tactic-column"><div class="tactic-head"><span>${esc(tactic.id)}</span><strong>${esc(tactic.name)}</strong><div class="tactic-count">${items.length} técnicas e sub-técnicas</div></div><div class="technique-list">${items.map(item => {
      const coverage = coverageFor(item.id);
      return `<button class="technique ${coverage.length?"is-covered":""} ${coverage.length>1?"is-multi":""}" data-action="mitre-detail" data-technique="${esc(item.id)}"><span>${esc(item.id)}</span><strong>${esc(item.name)}</strong>${coverage.length?`<small>${coverage.length} teste${coverage.length===1?"":"s"} concluído${coverage.length===1?"":"s"}</small>`:""}</button>`;
    }).join("")}</div></section>`;
  }).join("");
}

function openMitreDrawer(id) {
  const item = uniqueTechniques().find(t => t.id === id);
  if (!item) return;
  const coverage = coverageFor(id);
  const drawer = document.createElement("aside");
  drawer.className = "drawer";
  const description=(item.description||"").replace(/\[(.*?)\]\([^)]*\)/g,"$1").replace(/<[^>]+>/g,"").replace(/\(Citation:[^)]+\)/g,"").replace(/\s+/g," ").trim();
  drawer.innerHTML = `<button class="drawer-close" data-action="close-drawer">×</button><p class="eyebrow">${esc(item.id)} • MITRE ATT&CK</p><h2>${esc(item.name)}</h2><p>${esc(description.slice(0,1200))}</p><a class="button button-ghost" href="${esc(item.url)}" target="_blank" rel="noopener">Abrir no MITRE ↗</a><div class="section-head"><div><h2>Cobertura registrada</h2><p>${coverage.length} cenário${coverage.length===1?"":"s"} concluído${coverage.length===1?"":"s"}</p></div></div>${coverage.length ? coverage.map(row=>`<div class="coverage-item"><strong>${esc(row.exercise.id)} • ${esc(row.exercise.title)}</strong><span>${esc(row.scenario.id)} — ${esc(row.scenario.title)}</span></div>`).join("") : `<div class="empty"><strong>Ainda não coberta</strong><p>Nenhum cenário concluído usa esta técnica.</p></div>`}`;
  document.body.append(drawer);
}

function modal(title, subtitle, body, wide = false) {
  $("#modal-root").innerHTML = `<div class="modal-backdrop"><section class="modal ${wide?"wide":""}" role="dialog" aria-modal="true"><div class="modal-head"><div><h2>${esc(title)}</h2><p>${esc(subtitle||"")}</p></div><button class="modal-close" data-action="close-modal" aria-label="Fechar">×</button></div><div class="modal-body">${body}</div></section></div>`;
}
function closeModal() { $("#modal-root").innerHTML = ""; }

function openNewExercise() {
  const year = new Date().getFullYear();
  modal("Criar novo exercício", "Cadastre as informações iniciais. Os demais campos poderão ser preenchidos em Editar.", `<form data-form="new-exercise"><div class="form-grid"><div class="field"><label>ID</label><input name="id" value="PT-${year}-${String(state.exercises.length+1).padStart(3,"0")}" required pattern="PT-[0-9]{4}-[0-9]{3}"></div><div class="field"><label>Quarter</label><input name="quarter" value="${year}/Q${Math.ceil((new Date().getMonth()+1)/3)}" required></div><div class="field span-2"><label>Título</label><input name="title" required placeholder="Nome do exercício"></div><div class="field"><label>Objetivos</label><textarea name="objectives" required></textarea></div><div class="field"><label>Ambiente alvo</label><textarea name="target" required></textarea></div><div class="field span-2"><label>Restrições</label><textarea name="restrictions"></textarea></div></div><div class="form-actions"><button type="button" class="button button-ghost" data-action="close-modal">Cancelar</button><button class="button button-red" type="submit">Criar exercício</button></div></form>`, true);
}

function techniqueOptions(selected = "") {
  return uniqueTechniques().map(t => `<option value="${esc(t.id)}" ${t.id===selected?"selected":""}>${esc(t.id)} — ${esc(t.name)}</option>`).join("");
}

function openNewScenario(exercise) {
  modal("Novo cenário", `O ID será criado automaticamente como filho de ${exercise.id}.`, `<form data-form="new-scenario" data-exercise="${esc(exercise.id)}"><div class="form-grid"><div class="field span-2"><label>Cenário</label><input name="title" required></div><div class="field"><label>TTP MITRE</label><select name="ttp" required><option value="">Selecione</option>${techniqueOptions()}</select></div><div class="field"><label>IP origem</label><input name="sourceIp" placeholder="10.0.0.10"></div><div class="field span-2"><label>Procedimento / comando</label><textarea name="procedure" required></textarea></div></div><div class="form-actions"><button type="button" class="button button-ghost" data-action="close-modal">Cancelar</button><button class="button button-red" type="submit">Salvar cenário</button></div></form>`, true);
}

function openSkipScenario(exercise, scenario) {
  modal("Marcar como não executado", scenario.id, `<form data-form="skip-scenario" data-exercise="${esc(exercise.id)}" data-scenario="${esc(scenario.id)}"><div class="field"><label>Observação</label><textarea name="reason" required placeholder="Por que não foi possível executar?"></textarea></div><div class="form-actions"><button type="button" class="button button-ghost" data-action="close-modal">Cancelar</button><button class="button button-red" type="submit">Confirmar</button></div></form>`);
}

function openNewAction(exercise) {
  const scenarios = (exercise.scenarios || []).filter(s => ["complete","detection"].includes(s.status));
  modal("Nova ação de detecção", "Relacione um ou mais cenários executados.", `<form data-form="new-action" data-exercise="${esc(exercise.id)}"><div class="field"><label>Cenário / IDs relacionados</label><div style="display:grid;grid-template-columns:repeat(2,1fr);gap:8px">${scenarios.map(s=>`<label style="font-size:11px;text-transform:none;letter-spacing:0"><input type="checkbox" name="scenarioIds" value="${esc(s.id)}"> ${esc(s.id)} • ${esc(s.title)}</label>`).join("")||"Nenhum cenário executado."}</div></div><div class="form-grid" style="margin-top:16px"><div class="field"><label>Melhoria no EDR</label><textarea name="edr" required></textarea></div><div class="field"><label>Outras camadas de detecção</label><textarea name="other"></textarea></div><div class="field"><label>Medidas preventivas</label><textarea name="preventive"></textarea></div><div class="field"><label>Prioridade</label><select name="priority" required><option>Crítica</option><option>Alta</option><option selected>Média</option><option>Baixa</option></select><label>Regra implementada</label><select name="implemented"><option>Não</option><option>Sim</option></select></div></div><div class="form-actions"><button type="button" class="button button-ghost" data-action="close-modal">Cancelar</button><button class="button button-red" type="submit">Adicionar ação</button></div></form>`, true);
}

function openNewVulnerability(exercise) {
  modal("Nova vulnerabilidade", `O ID será criado automaticamente a partir de ${exercise.id}.`, `<form data-form="new-vulnerability" data-exercise="${esc(exercise.id)}"><div class="form-grid"><div class="field"><label>Vulnerabilidade</label><input name="title" required></div><div class="field"><label>Severidade</label><select name="severity"><option>Crítica</option><option>Alta</option><option selected>Média</option><option>Baixa</option></select></div><div class="field span-2"><label>Descrição</label><textarea name="description" required></textarea></div><div class="field"><label>CVE</label><input name="cve" placeholder="CVE-AAAA-NNNN"></div><div class="field"><label>CVSS</label><input name="cvss" placeholder="0.0 ou vetor CVSS"></div><div class="field"><label>Evidência</label><input type="file" name="evidence" multiple></div><div class="field"><label>Observação</label><textarea name="observation"></textarea></div></div><div class="form-actions"><button type="button" class="button button-ghost" data-action="close-modal">Cancelar</button><button class="button button-red" type="submit">Registrar vulnerabilidade</button></div></form>`, true);
}

function openReportModal(exercise) {
  modal("Gerar relatório DOCX", "Registre a nova versão no histórico do documento.", `<form data-form="report" data-exercise="${esc(exercise.id)}"><div class="form-grid"><div class="field"><label>Versão</label><input name="version" value="${exercise.history?.length ? "1."+exercise.history.length : "0.1"}" required></div><div class="field"><label>Criador</label><input name="creator" required></div><div class="field"><label>Data</label><input name="date" type="date" value="${new Date().toISOString().slice(0,10)}" required></div><div class="field"><label>Descrição</label><input name="description" value="Geração do relatório" required></div></div><div class="form-actions"><button type="button" class="button button-ghost" data-action="close-modal">Cancelar</button><button class="button button-red" type="submit">Gerar e baixar .docx</button></div></form>`);
}

function fileMeta(files) { return [...(files || [])].map(file => ({ name: file.name, size: file.size, type: file.type })); }

document.addEventListener("click", async event => {
  const button = event.target.closest("button,[data-nav]");
  if (!button) return;
  const action = button.dataset.action;
  const nav = button.dataset.nav || button.dataset.route;
  if (nav) return navigate(nav, button.dataset.id || null);
  if (action === "logout") {
    try { await api("/api/auth/logout", { method: "POST", body: "{}" }); }
    catch (_) {}
    location.hash = "dashboard";
    return showLogin("Sessão encerrada com segurança.");
  }
  if (action === "delete-user") {
    if (!confirm(`Excluir o usuário "${button.dataset.userName}"? Esta ação encerra também as sessões desse usuário.`)) return;
    try {
      await api(`/api/users/${encodeURIComponent(button.dataset.userId)}`, { method: "DELETE", body: "{}" });
      toast("Usuário excluído.");
      return loadUsers();
    } catch (error) {
      return toast(error.message);
    }
  }
  if (action === "new-exercise") return openNewExercise();
  if (action === "close-modal") return closeModal();
  if (action === "close-drawer") return button.closest(".drawer")?.remove();
  if (action === "toggle-exercise") return button.closest(".exercise-card")?.classList.toggle("is-open");
  if (action === "toggle-record") return button.closest(".record")?.classList.toggle("is-open");
  if (action === "new-scenario") return openNewScenario(exerciseById(button.dataset.id || routeState.exerciseId));
  if (action === "new-action") return openNewAction(exerciseById(button.dataset.id || routeState.exerciseId));
  if (action === "new-vulnerability") return openNewVulnerability(exerciseById(button.dataset.id || routeState.exerciseId));
  if (action === "report") return openReportModal(exerciseById(button.dataset.id));
  if (action === "mitre-detail") return openMitreDrawer(button.dataset.technique);
  if (action === "scenario-start") {
    const exercise = exerciseById(button.dataset.exercise); const scenario = exercise.scenarios.find(s => s.id === button.dataset.scenario);
    scenario.status = "running"; scenario.startAt = nowIso(); exercise.updatedAt = nowIso(); saveState("Execução iniciada e horário registrado."); return render();
  }
  if (action === "scenario-complete") {
    const exercise = exerciseById(button.dataset.exercise); const scenario = exercise.scenarios.find(s => s.id === button.dataset.scenario);
    scenario.status = "detection"; scenario.endAt = nowIso(); exercise.updatedAt = nowIso(); saveState("Execução encerrada. Preencha os dados de detecção."); render();
    requestAnimationFrame(() => document.querySelector(`[data-record="${CSS.escape(scenario.id)}"]`)?.classList.add("is-open")); return;
  }
  if (action === "scenario-skip") {
    const exercise = exerciseById(button.dataset.exercise); const scenario = exercise.scenarios.find(s => s.id === button.dataset.scenario); return openSkipScenario(exercise, scenario);
  }
  if (action === "toggle-action") {
    const exercise = exerciseById(button.dataset.exercise); const item = exercise.actions.find(a => a.id === button.dataset.item); item.implemented = item.implemented === "Sim" ? "Não" : "Sim"; exercise.updatedAt = nowIso(); saveState("Plano de ação atualizado."); return render();
  }
  if (action === "add-participant") {
    const exercise = exerciseById(button.dataset.id || routeState.exerciseId); exercise.participants ||= []; exercise.participants.push({company:"",team:"",name:"",role:"",email:""}); saveState(); return render();
  }
  if (action === "remove-participant") {
    const exercise = exerciseById(button.dataset.exercise); exercise.participants.splice(Number(button.dataset.index),1); saveState("Participante removido."); return render();
  }
  if (action === "export-data") {
    downloadBlob(new Blob([JSON.stringify(state,null,2)],{type:"application/json"}), `purple-team-backup-${new Date().toISOString().slice(0,10)}.json`); return toast("Backup exportado.");
  }
});

document.addEventListener("change", event => {
  const input = event.target;
  if (input.id === "import-data" && input.files?.[0]) {
    const reader = new FileReader();
    reader.onload = () => { try { const parsed = JSON.parse(reader.result); if (!Array.isArray(parsed.exercises)) throw new Error(); state = parsed; saveState("Dados importados com sucesso."); navigate("dashboard"); } catch (_) { toast("Arquivo de backup inválido."); } input.value = ""; };
    reader.readAsText(input.files[0]);
  }
  if (input.dataset.evidence === "scenario") {
    const exercise = exerciseById(input.dataset.exercise); const scenario = exercise.scenarios.find(s => s.id === input.dataset.scenario); scenario.evidence ||= []; scenario.evidence.push(...fileMeta(input.files)); saveState("Evidência registrada."); render(); requestAnimationFrame(() => document.querySelector(`[data-record="${CSS.escape(scenario.id)}"]`)?.classList.add("is-open"));
  }
});

document.addEventListener("input", event => {
  if (event.target.id === "mitre-search") $("#mitre-board").innerHTML = mitreColumns(event.target.value);
});

document.addEventListener("submit", async event => {
  event.preventDefault();
  const form = event.target;
  const type = form.dataset.form;
  const data = new FormData(form);
  if (type === "login") {
    const submit = form.querySelector("button[type=submit]");
    submit.disabled = true;
    submit.textContent = "Validando...";
    try {
      const payload = await api("/api/auth/login", {
        method: "POST",
        body: JSON.stringify({ username: data.get("username"), password: data.get("password") })
      });
      await loadMitre();
      activateSession(payload.user);
      return toast("Acesso autorizado.");
    } catch (error) {
      showLogin(error.message);
      return;
    }
  }
  if (type === "new-user") {
    const password = String(data.get("password"));
    const confirmation = String(data.get("passwordConfirm"));
    if (password !== confirmation) return toast("A confirmação da senha não confere.");
    if (password.length < 8 || !/[A-Z]/.test(password) || !/[^A-Za-z0-9]/.test(password)) {
      return toast("A senha deve ter 8 caracteres, maiúscula e caractere especial.");
    }
    try {
      await api("/api/users", {
        method: "POST",
        body: JSON.stringify({ username: data.get("username"), password })
      });
      form.reset();
      toast("Usuário criado.");
      return loadUsers();
    } catch (error) {
      return toast(error.message);
    }
  }
  if (type === "new-exercise") {
    const id = String(data.get("id")).trim().toUpperCase();
    if (state.exercises.some(e => e.id === id)) return toast("Já existe um exercício com esse ID.");
    state.exercises.push({ id, quarter:String(data.get("quarter")).trim(), title:String(data.get("title")).trim(), objectives:String(data.get("objectives")), target:String(data.get("target")), restrictions:String(data.get("restrictions")), participants:[], schedule:{}, result:"",cleanup:"",conclusions:"",summary:"",detectionResults:"",capacitySummary:"",scenarios:[],actions:[],vulnerabilities:[],history:[],createdAt:nowIso(),updatedAt:nowIso() });
    saveState("Exercício criado."); closeModal(); return navigate("edit",id);
  }
  if (type === "new-scenario") {
    const exercise = exerciseById(form.dataset.exercise); const seq = String((exercise.scenarios?.length||0)+1).padStart(3,"0"); const ttpId = String(data.get("ttp")); const t = uniqueTechniques().find(item => item.id === ttpId);
    exercise.scenarios ||= []; exercise.scenarios.push({ id:`${exercise.id}-${seq}`, title:String(data.get("title")), ttpId, ttpName:t?.name||"", sourceIp:String(data.get("sourceIp")), procedure:String(data.get("procedure")), status:"pending", startAt:"",endAt:"",evidence:[],detection:{alert:"",log:"",notes:"",evidence:[]} }); exercise.updatedAt=nowIso(); saveState("Cenário adicionado com status pendente."); closeModal(); return render();
  }
  if (type === "skip-scenario") {
    const exercise = exerciseById(form.dataset.exercise); const scenario = exercise.scenarios.find(s=>s.id===form.dataset.scenario); scenario.status="skipped"; scenario.skipReason=String(data.get("reason")); exercise.updatedAt=nowIso(); saveState("Cenário marcado como não executado."); closeModal(); return render();
  }
  if (type === "detection") {
    const exercise = exerciseById(form.dataset.exercise); const scenario = exercise.scenarios.find(s=>s.id===form.dataset.scenario); scenario.detection={ alert:String(data.get("alert")), log:String(data.get("log")), notes:String(data.get("notes")), evidence:[...(scenario.detection?.evidence||[]),...fileMeta(form.elements.evidence.files)] }; scenario.status="complete"; exercise.updatedAt=nowIso(); saveState("Detecção salva e cenário concluído."); return render();
  }
  if (type === "action-context") {
    const exercise=exerciseById(form.dataset.exercise); exercise.detectionResults=String(data.get("detectionResults")); exercise.capacitySummary=String(data.get("capacitySummary")); exercise.updatedAt=nowIso(); saveState("Contexto de detecção salvo."); return render();
  }
  if (type === "new-action") {
    const exercise=exerciseById(form.dataset.exercise); const scenarioIds=data.getAll("scenarioIds"); if(!scenarioIds.length) return toast("Selecione ao menos um cenário relacionado."); exercise.actions ||= []; exercise.actions.push({id:uid("act"),scenarioIds,edr:String(data.get("edr")),other:String(data.get("other")),preventive:String(data.get("preventive")),priority:String(data.get("priority")),implemented:String(data.get("implemented"))}); exercise.updatedAt=nowIso(); saveState("Ação adicionada ao plano."); closeModal(); return render();
  }
  if (type === "new-vulnerability") {
    const exercise=exerciseById(form.dataset.exercise); exercise.vulnerabilities ||= []; const seq=String(exercise.vulnerabilities.length+1).padStart(3,"0"); exercise.vulnerabilities.push({id:`${exercise.id}-V${seq}`,title:String(data.get("title")),description:String(data.get("description")),severity:String(data.get("severity")),cve:String(data.get("cve")),cvss:String(data.get("cvss")),observation:String(data.get("observation")),evidence:fileMeta(form.elements.evidence.files)}); exercise.updatedAt=nowIso(); saveState("Vulnerabilidade registrada."); closeModal(); return render();
  }
  if (type === "exercise-edit") {
    const exercise=exerciseById(form.dataset.exercise); ["quarter","title","objectives","target","restrictions","result","cleanup","conclusions","summary"].forEach(key=>exercise[key]=String(data.get(key))); exercise.updatedAt=nowIso(); saveState("Informações do exercício salvas."); return render();
  }
  if (type === "participants") {
    const exercise=exerciseById(form.dataset.exercise); exercise.participants=$$("tbody tr",form).map(row=>({company:$("[name=company]",row).value,team:$("[name=team]",row).value,name:$("[name=name]",row).value,role:$("[name=role]",row).value,email:$("[name=email]",row).value})); exercise.updatedAt=nowIso(); saveState("Participantes salvos."); return render();
  }
  if (type === "schedule") {
    const exercise=exerciseById(form.dataset.exercise); exercise.schedule={}; ["kickoff","preparation","execution","report","delivery"].forEach(key=>exercise.schedule[key]={start:String(data.get(`${key}-start`)),end:String(data.get(`${key}-end`))}); exercise.updatedAt=nowIso(); saveState("Cronograma salvo."); return render();
  }
  if (type === "report") {
    const exercise=exerciseById(form.dataset.exercise); const rawDate=String(data.get("date")); const date=rawDate?new Intl.DateTimeFormat("pt-BR").format(new Date(`${rawDate}T12:00:00`)):todayBr(); exercise.history ||= [];
    const entry={version:String(data.get("version")),creator:String(data.get("creator")),date,description:String(data.get("description"))}; exercise.history.push(entry); exercise.updatedAt=nowIso();
    try { await generateDocx(exercise); saveState(); closeModal(); return toast("Relatório DOCX gerado com o padrão visual do modelo."); }
    catch (error) { exercise.history.pop(); console.error(error); return toast("Não foi possível gerar o relatório. Tente novamente."); }
  }
});

window.addEventListener("hashchange", () => { if (!authUser) return; parseHash(); render(); });

function downloadBlob(blob, filename) {
  const url = URL.createObjectURL(blob); const a = document.createElement("a"); a.href=url; a.download=filename; document.body.append(a); a.click(); a.remove(); setTimeout(()=>URL.revokeObjectURL(url),1500);
}

const xesc = value => String(value ?? "").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&apos;"}[c]));
function wRun(text,bold=false,color="000000",size=20) { return `<w:r><w:rPr>${bold?"<w:b/>":""}<w:color w:val="${color}"/><w:sz w:val="${size}"/><w:szCs w:val="${size}"/></w:rPr><w:t xml:space="preserve">${xesc(text)}</w:t></w:r>`; }
function wPara(text,opts={}) { const {style="Normal",bold=false,color="000000",size=20,align="left",after=120,before=0,pageBreak=false}=opts; return `<w:p><w:pPr><w:pStyle w:val="${style}"/><w:jc w:val="${align}"/><w:spacing w:before="${before}" w:after="${after}"/>${pageBreak?"<w:pageBreakBefore/>":""}</w:pPr>${wRun(text,bold,color,size)}</w:p>`; }
function wHeading(text,level=1) { return wPara(text,{style:level===1?"BradescoT1":"BradescoT2",bold:true,size:level===1?30:24,before:260,after:130}); }
function wCell(text,opts={}) { const {header=false,fill=header?"C00000":"FFFFFF",color=header?"FFFFFF":"000000",bold=header,width=1800}=opts; return `<w:tc><w:tcPr><w:tcW w:w="${width}" w:type="dxa"/><w:shd w:fill="${fill}"/><w:tcMar><w:top w:w="80" w:type="dxa"/><w:left w:w="90" w:type="dxa"/><w:bottom w:w="80" w:type="dxa"/><w:right w:w="90" w:type="dxa"/></w:tcMar></w:tcPr>${wPara(text,{bold,color,size:17,after:0})}</w:tc>`; }
function wTable(headers, rows, fills={}) {
  const width=Math.floor(10800/Math.max(headers.length,1));
  const borders=`<w:tblBorders><w:top w:val="single" w:sz="4" w:color="D9D9D9"/><w:left w:val="single" w:sz="4" w:color="D9D9D9"/><w:bottom w:val="single" w:sz="4" w:color="D9D9D9"/><w:right w:val="single" w:sz="4" w:color="D9D9D9"/><w:insideH w:val="single" w:sz="4" w:color="D9D9D9"/><w:insideV w:val="single" w:sz="4" w:color="D9D9D9"/></w:tblBorders>`;
  return `<w:tbl><w:tblPr><w:tblStyle w:val="BradescoTB1"/><w:tblW w:w="10800" w:type="dxa"/>${borders}</w:tblPr><w:tblGrid>${headers.map(()=>`<w:gridCol w:w="${width}"/>`).join("")}</w:tblGrid><w:tr>${headers.map(h=>wCell(h,{header:true,width})).join("")}</w:tr>${rows.map((row,ri)=>`<w:tr>${row.map(cell=>wCell(cell,{width,fill:fills[ri]||((ri%2)?"F7F4F5":"FFFFFF")})).join("")}</w:tr>`).join("")}</w:tbl>${wPara("",{after:90})}`;
}
function tacticForTechnique(id) {
  for (const tactic of mitre.tactics) if (tactic.techniques.some(item=>item.id===id)) return tactic;
  return {id:"—",name:"—"};
}
function ptMonthYear(exercise) {
  const candidate=exercise.schedule?.delivery?.end||exercise.schedule?.execution?.end||new Date().toISOString().slice(0,10);
  const d=new Date(`${candidate}T12:00:00`); const label=new Intl.DateTimeFormat("pt-BR",{month:"long",year:"numeric"}).format(d); return label.charAt(0).toUpperCase()+label.slice(1);
}
const W_NS="http://schemas.openxmlformats.org/wordprocessingml/2006/main";
const XML_MIME="application/xml";
const utf8Encoder=new TextEncoder();
const utf8Decoder=new TextDecoder("utf-8");

function rowsOrPlaceholder(rows,columns) { return rows.length?rows:[Array(columns).fill("—")]; }
function textParagraphs(value) { const text=String(value||"Não informado.").trim()||"Não informado."; return text.split(/\r?\n+/).map(line=>wPara(line)).join(""); }
function paragraphText(node) { return [...node.getElementsByTagNameNS(W_NS,"t")].map(item=>item.textContent||"").join("").trim(); }
function paragraphByText(doc,text) { return [...doc.getElementsByTagNameNS(W_NS,"p")].find(node=>paragraphText(node)===text); }
function replaceParagraphText(doc,target,value) {
  const paragraph=paragraphByText(doc,target); if(!paragraph) throw new Error(`Slot não encontrado no modelo: ${target}`);
  const textNodes=[...paragraph.getElementsByTagNameNS(W_NS,"t")]; if(!textNodes.length) throw new Error(`Slot sem texto no modelo: ${target}`);
  textNodes[0].textContent=String(value); textNodes.slice(1).forEach(node=>node.textContent="");
}
function fragmentNodes(doc,xml) {
  const parsed=new DOMParser().parseFromString(`<root xmlns:w="${W_NS}">${xml}</root>`,XML_MIME);
  if(parsed.getElementsByTagName("parsererror").length) throw new Error("Falha ao montar conteúdo OOXML.");
  return [...parsed.documentElement.childNodes].map(node=>doc.importNode(node,true));
}
function replaceSectionContent(doc,startTitle,endTitle,xml) {
  const start=paragraphByText(doc,startTitle); if(!start) throw new Error(`Seção não encontrada: ${startTitle}`);
  const end=endTitle?paragraphByText(doc,endTitle):[...start.parentNode.childNodes].find(node=>node.localName==="sectPr");
  if(!end||start.parentNode!==end.parentNode) throw new Error(`Limite da seção não encontrado: ${startTitle}`);
  let cursor=start.nextSibling; while(cursor&&cursor!==end){const next=cursor.nextSibling;cursor.remove();cursor=next;}
  fragmentNodes(doc,xml).forEach(node=>end.parentNode.insertBefore(node,end));
}
function buildTemplateSections(exercise) {
  const executed=(exercise.scenarios||[]).filter(s=>s.status==="complete");
  const skipped=(exercise.scenarios||[]).filter(s=>s.status==="skipped");
  const unique=[...new Map(executed.map(s=>[s.ttpId,s])).values()];
  const scheduleLabels={kickoff:"Kick-off",preparation:"Preparação",execution:"Execução",report:"Relatório",delivery:"Entrega"};
  const severityCounts={Crítica:0,Alta:0,Média:0,Baixa:0}; (exercise.vulnerabilities||[]).forEach(v=>severityCounts[v.severity]=(severityCounts[v.severity]||0)+1);

  const objectives=[textParagraphs(exercise.objectives),wHeading("CENÁRIO",2),wTable(["ID Tática","Tática","ID Técnica","Técnica","Descrição / procedimento"],rowsOrPlaceholder(unique.map(s=>{const t=tacticForTechnique(s.ttpId);return[t.id,t.name,s.ttpId,s.ttpName,s.procedure||s.title]}),5)),wHeading("AMBIENTE ALVO",2),textParagraphs(exercise.target)].join("");
  const participants=wTable(["EMPRESA","EQUIPE","NOME","FUNÇÃO","E-MAIL"],rowsOrPlaceholder((exercise.participants||[]).map(p=>[p.company,p.team,p.name,p.role,p.email]),5));
  const schedule=wTable(["ID","ATIVIDADE","INÍCIO","FIM"],Object.entries(scheduleLabels).map(([key,label],i)=>[String(i+1),label,exercise.schedule?.[key]?.start||"—",exercise.schedule?.[key]?.end||"—"]));

  const results=[textParagraphs(exercise.result),wTable(["Cenários executados","Quantidade"],[["Concluídos",String(executed.length)],["Não executados ou descartados",String(skipped.length)],["Total",String((exercise.scenarios||[]).length)]])];
  executed.forEach(s=>results.push(wHeading(`${s.id} - ${s.title}`,2),wTable(["TÉCNICA ATT&CK","INÍCIO","FINAL","IP ORIGEM"],[[`${s.ttpId} - ${s.ttpName}`,dateTime(s.startAt),dateTime(s.endAt),s.sourceIp||"—"]]),wPara(`Procedimento: ${s.procedure||"—"}`),wPara(`Evidências: ${(s.evidence||[]).map(e=>e.name).join(", ")||"Nenhuma"}`)));
  results.push(wHeading("Cenários não executados/descartados",2),wTable(["Cenário","TTP","Observação"],rowsOrPlaceholder(skipped.map(s=>[s.id,`${s.ttpId} - ${s.ttpName}`,s.skipReason||"—"]),3)),wHeading("Resultados de Detecção",2),textParagraphs(exercise.detectionResults),wTable(["ID","Cenário executado","Log disponível","Alerta gerado","Observações"],rowsOrPlaceholder(executed.map(s=>[s.id,s.title,s.detection?.log||"—",s.detection?.alert||"—",s.detection?.notes||"—"]),5)),wHeading("Resumo da capacidade",2),textParagraphs(exercise.capacitySummary));

  const actions=wTable(["Cenário / IDs relacionados","Melhoria no EDR","Outras camadas de detecção","Medidas preventivas","Prioridade","Regra implementada"],rowsOrPlaceholder((exercise.actions||[]).map(a=>[(a.scenarioIds||[]).join("; "),a.edr,a.other,a.preventive,a.priority,a.implemented]),6));
  const vulnerabilities=[wTable(["ID","Título","Severidade","CVE","CVSS"],rowsOrPlaceholder((exercise.vulnerabilities||[]).map(v=>[v.id,v.title,v.severity,v.cve||"—",v.cvss||"—"]),5)),wHeading("DISTRIBUIÇÃO POR CRITICIDADE",2),wTable(["Criticidade","Quantidade"],[["Crítica",String(severityCounts.Crítica)],["Alta",String(severityCounts.Alta)],["Média",String(severityCounts.Média)],["Baixa",String(severityCounts.Baixa)]],{0:"8064A2",1:"C00000",2:"FFC000",3:"4F81BD"})].join("");
  const vulnerabilityDetails=[]; (exercise.vulnerabilities||[]).forEach(v=>vulnerabilityDetails.push(wHeading(`${v.id} - ${v.title}`,2),wTable(["Descrição","Severidade","CVE","CVSS"],[[v.description,v.severity,v.cve||"—",v.cvss||"—"]]),wPara(`Observação: ${v.observation||"—"}`),wPara(`Evidências: ${(v.evidence||[]).map(e=>e.name).join(", ")||"Nenhuma"}`)));
  if(!vulnerabilityDetails.length) vulnerabilityDetails.push(wPara("Nenhuma vulnerabilidade registrada."));

  return {
    objectives,
    restrictions:textParagraphs(exercise.restrictions),
    participants,
    schedule,
    results:results.join(""),
    actions,
    vulnerabilities,
    vulnerabilityDetails:vulnerabilityDetails.join(""),
    cleanup:textParagraphs(exercise.cleanup),
    conclusions:textParagraphs(exercise.conclusions),
    summary:textParagraphs(exercise.summary),
    history:wTable(["Versão","Criador","Data","Descrição"],rowsOrPlaceholder((exercise.history||[]).map(h=>[h.version,h.creator,h.date,h.description]),4))
  };
}

function patchTemplateReport(files,exercise) {
  const parser=new DOMParser(); const serializer=new XMLSerializer();
  const documentXml=utf8Decoder.decode(files["word/document.xml"]); const doc=parser.parseFromString(documentXml,XML_MIME);
  if(doc.getElementsByTagName("parsererror").length) throw new Error("O modelo DOCX contém XML inválido.");
  replaceParagraphText(doc,"PT-AAAA-XXX",exercise.id);
  replaceParagraphText(doc,"<TITULO DO RELATÓRIO>",exercise.title.toUpperCase());
  replaceParagraphText(doc,"mês de ano/QN",`${ptMonthYear(exercise)}/${(exercise.quarter||"").split("/").pop()}`);
  const sections=buildTemplateSections(exercise);
  replaceSectionContent(doc,"OBJETIVOS","RESTRIÇÕES",sections.objectives);
  replaceSectionContent(doc,"RESTRIÇÕES","PARTICIPANTES",sections.restrictions);
  replaceSectionContent(doc,"PARTICIPANTES","CRONOGRAMA",sections.participants);
  replaceSectionContent(doc,"CRONOGRAMA","RESULTADOS DO EXERCÍCIO",sections.schedule);
  replaceSectionContent(doc,"RESULTADOS DO EXERCÍCIO","OBSERVAÇÕES E RECOMENDAÇÕES",sections.results);
  replaceSectionContent(doc,"OBSERVAÇÕES E RECOMENDAÇÕES","VULNERABILIDADES",sections.actions);
  replaceSectionContent(doc,"VULNERABILIDADES","DESCRIÇÃO DAS VULNERABILIDADES",sections.vulnerabilities);
  replaceSectionContent(doc,"DESCRIÇÃO DAS VULNERABILIDADES","CLEAN UP",sections.vulnerabilityDetails);
  replaceSectionContent(doc,"CLEAN UP","CONCLUSÕES",sections.cleanup);
  replaceSectionContent(doc,"CONCLUSÕES","RESUMO DOS PRINCIPAIS RESULTADOS",sections.conclusions);
  replaceSectionContent(doc,"RESUMO DOS PRINCIPAIS RESULTADOS","HISTÓRICO DO DOCUMENTO",sections.summary);
  replaceSectionContent(doc,"HISTÓRICO DO DOCUMENTO",null,sections.history);
  files["word/document.xml"]=utf8Encoder.encode(serializer.serializeToString(doc));

  if(files["word/settings.xml"]) {
    const settings=parser.parseFromString(utf8Decoder.decode(files["word/settings.xml"]),XML_MIME); let update=settings.getElementsByTagNameNS(W_NS,"updateFields")[0];
    if(!update){update=settings.createElementNS(W_NS,"w:updateFields");settings.documentElement.append(update);} update.setAttributeNS(W_NS,"w:val","true"); files["word/settings.xml"]=utf8Encoder.encode(serializer.serializeToString(settings));
  }
  if(files["docProps/core.xml"]) {
    const core=parser.parseFromString(utf8Decoder.decode(files["docProps/core.xml"]),XML_MIME); const title=core.getElementsByTagNameNS("http://purl.org/dc/elements/1.1/","title")[0]; if(title) title.textContent=`${exercise.id} ${exercise.title}`; files["docProps/core.xml"]=utf8Encoder.encode(serializer.serializeToString(core));
  }
  return files;
}

async function unzipEntries(buffer) {
  const bytes=new Uint8Array(buffer); const view=new DataView(buffer); let eocd=-1;
  for(let i=bytes.length-22;i>=Math.max(0,bytes.length-65557);i--){if(view.getUint32(i,true)===0x06054b50){eocd=i;break;}}
  if(eocd<0) throw new Error("Estrutura ZIP do modelo não encontrada.");
  const count=view.getUint16(eocd+10,true); let cursor=view.getUint32(eocd+16,true); const files={};
  for(let i=0;i<count;i++) {
    if(view.getUint32(cursor,true)!==0x02014b50) throw new Error("Diretório ZIP inválido.");
    const method=view.getUint16(cursor+10,true), compressedSize=view.getUint32(cursor+20,true), nameLength=view.getUint16(cursor+28,true), extraLength=view.getUint16(cursor+30,true), commentLength=view.getUint16(cursor+32,true), localOffset=view.getUint32(cursor+42,true);
    const name=utf8Decoder.decode(bytes.slice(cursor+46,cursor+46+nameLength));
    const localNameLength=view.getUint16(localOffset+26,true), localExtraLength=view.getUint16(localOffset+28,true), dataStart=localOffset+30+localNameLength+localExtraLength; const compressed=bytes.slice(dataStart,dataStart+compressedSize);
    if(method===0) files[name]=compressed;
    else if(method===8) { const stream=new Blob([compressed]).stream().pipeThrough(new DecompressionStream("deflate-raw")); files[name]=new Uint8Array(await new Response(stream).arrayBuffer()); }
    else throw new Error(`Compressão ZIP não suportada: ${method}`);
    cursor+=46+nameLength+extraLength+commentLength;
  }
  return files;
}

async function generateDocx(exercise) {
  const response=await fetch("./assets/report-template.docx",{cache:"no-store"}); if(!response.ok) throw new Error("Modelo DOCX não disponível.");
  const files=patchTemplateReport(await unzipEntries(await response.arrayBuffer()),exercise);
  const blob=zipStore(files,"application/vnd.openxmlformats-officedocument.wordprocessingml.document");
  downloadBlob(blob,`${exercise.id}-${exercise.title.replace(/[^a-z0-9]+/gi,"-").replace(/^-|-$/g,"").toLowerCase()}.docx`);
}

let crcTable;
function makeCrcTable(){const table=new Uint32Array(256);for(let n=0;n<256;n++){let c=n;for(let k=0;k<8;k++)c=(c&1)?0xedb88320^(c>>>1):c>>>1;table[n]=c>>>0;}return table;}
function crc32(bytes){crcTable ||= makeCrcTable();let crc=0xffffffff;for(const b of bytes)crc=crcTable[(crc^b)&255]^(crc>>>8);return (crc^0xffffffff)>>>0;}
function le(size,...values){const buffer=new ArrayBuffer(size*values.length);const view=new DataView(buffer);values.forEach((value,i)=>{if(size===2)view.setUint16(i*size,value,true);else view.setUint32(i*size,value>>>0,true);});return new Uint8Array(buffer);}
function joinBytes(chunks){const length=chunks.reduce((n,c)=>n+c.length,0);const out=new Uint8Array(length);let offset=0;chunks.forEach(c=>{out.set(c,offset);offset+=c.length;});return out;}
function dosDateTime(date=new Date()){const year=Math.max(1980,date.getFullYear());return{time:(date.getHours()<<11)|(date.getMinutes()<<5)|(date.getSeconds()>>1),date:((year-1980)<<9)|((date.getMonth()+1)<<5)|date.getDate()};}
function zipStore(files,mime){const enc=new TextEncoder();const local=[];const central=[];let offset=0;const dt=dosDateTime();for(const [name,content] of Object.entries(files)){const nameBytes=enc.encode(name);const data=typeof content==="string"?enc.encode(content):content;const crc=crc32(data);const header=joinBytes([le(4,0x04034b50),le(2,20,0x0800,0,dt.time,dt.date),le(4,crc,data.length,data.length),le(2,nameBytes.length,0),nameBytes]);local.push(header,data);const center=joinBytes([le(4,0x02014b50),le(2,20,20,0x0800,0,dt.time,dt.date),le(4,crc,data.length,data.length),le(2,nameBytes.length,0,0,0,0),le(4,0,offset),nameBytes]);central.push(center);offset+=header.length+data.length;}const centralBytes=joinBytes(central);const end=joinBytes([le(4,0x06054b50),le(2,0,0,Object.keys(files).length,Object.keys(files).length),le(4,centralBytes.length,offset),le(2,0)]);return new Blob([...local,centralBytes,end],{type:mime});}

async function loadMitre() {
  try { const response=await fetch("./assets/mitre-enterprise.json"); mitre=await response.json(); }
  catch (_) { mitre={tactics:[]}; toast("Não foi possível carregar o catálogo MITRE."); }
}

async function init() {
  showLogin();
  try {
    const payload = await api("/api/auth/me", { method: "GET" });
    await loadMitre();
    activateSession(payload.user);
  } catch (_) {}
}
init();
