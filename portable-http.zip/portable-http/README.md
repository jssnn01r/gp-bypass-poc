# Purple Team Control — edição portátil

Aplicação estática para execução local com `python -m http.server`. Não exige dependências nem banco de dados.

## Iniciar

Abra o PowerShell nesta pasta e execute:

```powershell
python -m http.server 8000 --bind 127.0.0.1
```

Acesse `http://127.0.0.1:8000`.

Como alternativa no Windows, execute `./start-local.ps1`. O launcher procura automaticamente uma instalação válida do Python 3.

Credencial inicial: usuário `BJ` e a senha definida na entrega original do projeto.

## Armazenamento

- Exercícios e usuários ficam no `localStorage` do navegador.
- A sessão atual fica no `sessionStorage`.
- Use **Exportar dados** periodicamente. Limpar os dados do navegador apaga os registros locais.
- Cada navegador/perfil mantém uma base independente.

## Segurança

Esta edição possui uma barreira de acesso local com senhas derivadas por PBKDF2-SHA-256 (100.000 iterações), mas não possui backend. Código e armazenamento do navegador podem ser alterados pelo próprio visitante.

- Adequada para uso individual/offline em máquina confiável.
- Não expor diretamente à Internet.
- `python -m http.server` não fornece HTTPS, banco, cookies `HttpOnly`, auditoria central ou autorização no servidor.
- Para acesso multiusuário seguro, use a versão hospedada com backend ou publique atrás de um servidor autenticado e HTTPS.

O Web Crypto utilizado pela autenticação funciona em `localhost`. Para acesso por outro computador via IP, configure HTTPS e uma camada real de autenticação.
